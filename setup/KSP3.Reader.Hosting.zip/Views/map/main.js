﻿//https://openlayers.org/en/latest/examples/static-image.html

const extent = [0, 0, 1024, 968];
const projection = new ol.proj.Projection({
    code: 'xkcd-image',
    units: 'pixels',
    extent: extent,
});

const map = new ol.Map({
    layers: [
        new ol.layer.Image({
            source: new ol.source.ImageStatic({
                attributions: '© <a href="https://xkcd.com/license.html">xkcd</a>',
                url: '/file?path=Views/map/map.png&type=image/png',
                projection: projection,
                imageExtent: extent,
            }),
        }),
    ],
    target: 'map',
    view: new ol.View({
        projection: projection,
        center: ol.extent.getCenter(extent),
        zoom: 2,
        maxZoom: 8,
    }),
});

async function getMeasureDataSummaryAll() {
    console.log("getMeasureDataSummaryAll");
    var respose = await fetch("http://localhost:8989/GetMeasureDataSummaryAll", {
        method: "POST",
        body: "{}",
        headers: {
            "Content-type": "application/json; charset=UTF-8"
        }
    });
    var data = await respose.json();
    console.log(data);
}

getMeasureDataSummaryAll();