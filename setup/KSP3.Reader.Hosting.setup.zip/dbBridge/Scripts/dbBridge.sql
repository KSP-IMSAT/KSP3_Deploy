--{DatabaseName}
--{ForderData}
--{Year}

USE [master]
GO
/****** Object:  Database [{DatabaseName}]    Script Date: 18/08 12:18:13 ******/
CREATE DATABASE [{DatabaseName}]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'{DatabaseName}', FILENAME = N'{ForderData}\{DatabaseName}.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'{DatabaseName}_log', FILENAME = N'{ForderData}\{DatabaseName}_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
GO
ALTER DATABASE [{DatabaseName}] SET COMPATIBILITY_LEVEL = 140
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [{DatabaseName}].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [{DatabaseName}] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [{DatabaseName}] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [{DatabaseName}] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [{DatabaseName}] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [{DatabaseName}] SET ARITHABORT OFF 
GO
ALTER DATABASE [{DatabaseName}] SET AUTO_CLOSE ON 
GO
ALTER DATABASE [{DatabaseName}] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [{DatabaseName}] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [{DatabaseName}] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [{DatabaseName}] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [{DatabaseName}] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [{DatabaseName}] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [{DatabaseName}] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [{DatabaseName}] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [{DatabaseName}] SET  ENABLE_BROKER 
GO
ALTER DATABASE [{DatabaseName}] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [{DatabaseName}] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [{DatabaseName}] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [{DatabaseName}] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [{DatabaseName}] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [{DatabaseName}] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [{DatabaseName}] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [{DatabaseName}] SET RECOVERY SIMPLE 
GO
ALTER DATABASE [{DatabaseName}] SET  MULTI_USER 
GO
ALTER DATABASE [{DatabaseName}] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [{DatabaseName}] SET DB_CHAINING OFF 
GO
ALTER DATABASE [{DatabaseName}] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [{DatabaseName}] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [{DatabaseName}] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [{DatabaseName}] SET QUERY_STORE = OFF
GO
USE [{DatabaseName}]
GO
/****** Object:  Table [dbo].[tblAdministration]    Script Date: 18/08 12:18:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblAdministration](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[col1] [nvarchar](4000) NOT NULL,
	[col2] [nvarchar](4000) NOT NULL,
	[col3] [nvarchar](4000) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[tblAlarm_CtrlLine]    Script Date: 18/08 12:18:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblAlarm_CtrlLine](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[idDevice] [int] NOT NULL,
	[AlarmHigh] [nvarchar](100) NOT NULL,
	[AlarmLow] [nvarchar](100) NOT NULL,
	[AlarmAPS] [nvarchar](100) NOT NULL,
	[AlarmRing] [nvarchar](100) NOT NULL,
	[ControlDevice] [int] NULL,
	[Calib] [nvarchar](100) NULL,
	[date_time] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[tblConnection]    Script Date: 18/08 12:18:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblConnection](
	[central] [nvarchar](100) NOT NULL,
	[TimerConnect] [nvarchar](100) NOT NULL,
	[ModScan] [nvarchar](100) NOT NULL,
	[StatusSTSL] [nvarchar](100) NOT NULL,
	[StatusSTSA] [nvarchar](255) NULL,
	[messageNotify] [nvarchar](4000) NULL,
	[UnoUdpEndpoint] [nvarchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[central] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[tblDevice]    Script Date: 18/08 12:18:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblDevice](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[name] [nvarchar](100) NOT NULL,
	[central] [nvarchar](100) NOT NULL,
	[Line] [nvarchar](100) NOT NULL,
	[Position] [nvarchar](100) NOT NULL,
	[SensorKod] [nvarchar](100) NOT NULL,
	[status] [nvarchar](100) NOT NULL,
	[X1Kod] [nvarchar](100) NULL,
	[X2Kod] [nvarchar](100) NULL,
	[EKod] [nvarchar](100) NULL,
	[TimeRequest] [nvarchar](255) NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[tblMeasure]    Script Date: 18/08 12:18:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblMeasure](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[idDevice] [int] NOT NULL,
	[Value] [nvarchar](100) NULL,
	[date_time] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[tblAdministration] ADD  DEFAULT (N'abc') FOR [col1]
GO
ALTER TABLE [dbo].[tblAdministration] ADD  DEFAULT (N'1') FOR [col2]
GO
ALTER TABLE [dbo].[tblAdministration] ADD  DEFAULT (N'1') FOR [col3]
GO
ALTER TABLE [dbo].[tblAlarm_CtrlLine] ADD  DEFAULT (N'0') FOR [ControlDevice]
GO
ALTER TABLE [dbo].[tblAlarm_CtrlLine] ADD  DEFAULT (N'0') FOR [Calib]
GO
ALTER TABLE [dbo].[tblAlarm_CtrlLine] ADD  DEFAULT (getdate()) FOR [date_time]
GO
ALTER TABLE [dbo].[tblConnection] ADD  DEFAULT (N'1') FOR [central]
GO
ALTER TABLE [dbo].[tblConnection] ADD  DEFAULT (N'C') FOR [ModScan]
GO
ALTER TABLE [dbo].[tblDevice] ADD  DEFAULT (N'abc') FOR [name]
GO
ALTER TABLE [dbo].[tblDevice] ADD  DEFAULT (N'1') FOR [central]
GO
ALTER TABLE [dbo].[tblDevice] ADD  DEFAULT (N'1') FOR [Line]
GO
ALTER TABLE [dbo].[tblDevice] ADD  DEFAULT (N'1') FOR [Position]
GO
ALTER TABLE [dbo].[tblDevice] ADD  DEFAULT (N'Off') FOR [status]
GO
ALTER TABLE [dbo].[tblMeasure] ADD  DEFAULT (N'0') FOR [Value]
GO
ALTER TABLE [dbo].[tblMeasure] ADD  DEFAULT (getdate()) FOR [date_time]
GO
ALTER TABLE [dbo].[tblAlarm_CtrlLine]  WITH CHECK ADD FOREIGN KEY([idDevice])
REFERENCES [dbo].[tblDevice] ([id])
GO
ALTER TABLE [dbo].[tblDevice]  WITH CHECK ADD FOREIGN KEY([central])
REFERENCES [dbo].[tblConnection] ([central])
GO
ALTER TABLE [dbo].[tblMeasure]  WITH CHECK ADD FOREIGN KEY([idDevice])
REFERENCES [dbo].[tblDevice] ([id])
GO
USE [master]
GO
ALTER DATABASE [{DatabaseName}] SET  READ_WRITE 
GO
