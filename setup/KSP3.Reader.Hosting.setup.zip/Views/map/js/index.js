const _win = window;
export default class App {
    constructor() {
        this.el = '#app';
        this.data = {
            message: 'Hello Vue!'
        };
        this.methods = {};
        this.computed = {};
        this.filters = {};
        this.created = () => {
            console.log('created');
        };
        this.mounted = () => {
            console.log(this.data.message);
        };
    }
}
_win._vm = new _win.Vue.createApp(new App());
