--{DatabaseName}
--{ForderData}
--{Year}

USE [master]
GO
/****** Object:  Database [{DatabaseName}]    Script Date: 18/04 11:23:17 ******/
CREATE DATABASE [{DatabaseName}]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'{DatabaseName}', FILENAME = N'{ForderData}\{DatabaseName}.mdf' , SIZE = 523456KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024KB ), 
 FILEGROUP [FG_{DatabaseName}_01] 
( NAME = N'{DatabaseName}_01', FILENAME = N'{ForderData}\{DatabaseName}_01.ndf' , SIZE = 3072KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024KB ), 
 FILEGROUP [FG_{DatabaseName}_02] 
( NAME = N'{DatabaseName}_02', FILENAME = N'{ForderData}\{DatabaseName}_02.ndf' , SIZE = 3072KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024KB ), 
 FILEGROUP [FG_{DatabaseName}_03] 
( NAME = N'{DatabaseName}_03', FILENAME = N'{ForderData}\{DatabaseName}_03.ndf' , SIZE = 3072KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024KB ), 
 FILEGROUP [FG_{DatabaseName}_04] 
( NAME = N'{DatabaseName}_04', FILENAME = N'{ForderData}\{DatabaseName}_04.ndf' , SIZE = 3072KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024KB ), 
 FILEGROUP [FG_{DatabaseName}_05] 
( NAME = N'{DatabaseName}_05', FILENAME = N'{ForderData}\{DatabaseName}_05.ndf' , SIZE = 3072KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024KB ), 
 FILEGROUP [FG_{DatabaseName}_06] 
( NAME = N'{DatabaseName}_06', FILENAME = N'{ForderData}\{DatabaseName}_06.ndf' , SIZE = 3072KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024KB ), 
 FILEGROUP [FG_{DatabaseName}_07] 
( NAME = N'{DatabaseName}_07', FILENAME = N'{ForderData}\{DatabaseName}_07.ndf' , SIZE = 3072KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024KB ), 
 FILEGROUP [FG_{DatabaseName}_08] 
( NAME = N'{DatabaseName}_08', FILENAME = N'{ForderData}\{DatabaseName}_08.ndf' , SIZE = 3072KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024KB ), 
 FILEGROUP [FG_{DatabaseName}_09] 
( NAME = N'{DatabaseName}_09', FILENAME = N'{ForderData}\{DatabaseName}_09.ndf' , SIZE = 3072KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024KB ), 
 FILEGROUP [FG_{DatabaseName}_10] 
( NAME = N'{DatabaseName}_10', FILENAME = N'{ForderData}\{DatabaseName}_10.ndf' , SIZE = 3072KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024KB ), 
 FILEGROUP [FG_{DatabaseName}_11] 
( NAME = N'{DatabaseName}_11', FILENAME = N'{ForderData}\{DatabaseName}_11.ndf' , SIZE = 3072KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024KB ), 
 FILEGROUP [FG_{DatabaseName}_12] 
( NAME = N'{DatabaseName}_12', FILENAME = N'{ForderData}\{DatabaseName}_12.ndf' , SIZE = 3072KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024KB )
 LOG ON 
( NAME = N'{DatabaseName}_log', FILENAME = N'{ForderData}\{DatabaseName}_log.ldf' , SIZE = 223104KB , MAXSIZE = 2048GB , FILEGROWTH = 10%)
GO
ALTER DATABASE [{DatabaseName}] SET COMPATIBILITY_LEVEL = 120
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [{DatabaseName}].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [{DatabaseName}] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [{DatabaseName}] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [{DatabaseName}] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [{DatabaseName}] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [{DatabaseName}] SET ARITHABORT OFF 
GO
ALTER DATABASE [{DatabaseName}] SET AUTO_CLOSE ON 
GO
ALTER DATABASE [{DatabaseName}] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [{DatabaseName}] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [{DatabaseName}] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [{DatabaseName}] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [{DatabaseName}] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [{DatabaseName}] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [{DatabaseName}] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [{DatabaseName}] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [{DatabaseName}] SET  ENABLE_BROKER 
GO
ALTER DATABASE [{DatabaseName}] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [{DatabaseName}] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [{DatabaseName}] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [{DatabaseName}] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [{DatabaseName}] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [{DatabaseName}] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [{DatabaseName}] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [{DatabaseName}] SET RECOVERY FULL 
GO
ALTER DATABASE [{DatabaseName}] SET  MULTI_USER 
GO
ALTER DATABASE [{DatabaseName}] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [{DatabaseName}] SET DB_CHAINING OFF 
GO
ALTER DATABASE [{DatabaseName}] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [{DatabaseName}] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [{DatabaseName}] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [{DatabaseName}] SET QUERY_STORE = OFF
GO
USE [{DatabaseName}]
GO
/****** Object:  PartitionFunction [PartitioningByMonth]    Script Date: 18/04 11:23:18 ******/
CREATE PARTITION FUNCTION [PartitioningByMonth](datetime) AS RANGE RIGHT FOR VALUES (N'{Year}-02-01T00:00:00.000', N'{Year}-03-01T00:00:00.000', N'{Year}-04-01T00:00:00.000', N'{Year}-05-01T00:00:00.000', N'{Year}-06-01T00:00:00.000', N'{Year}-07-01T00:00:00.000', N'{Year}-08-01T00:00:00.000', N'{Year}-09-01T00:00:00.000', N'{Year}-10-01T00:00:00.000', N'{Year}-11-01T00:00:00.000', N'{Year}-12-01T00:00:00.000')
GO
/****** Object:  PartitionScheme [PartitionBymonth]    Script Date: 18/04 11:23:18 ******/
CREATE PARTITION SCHEME [PartitionBymonth] AS PARTITION [PartitioningByMonth] TO ([FG_{DatabaseName}_01], [FG_{DatabaseName}_02], [FG_{DatabaseName}_03], [FG_{DatabaseName}_04], [FG_{DatabaseName}_05], [FG_{DatabaseName}_06], [FG_{DatabaseName}_07], [FG_{DatabaseName}_08], [FG_{DatabaseName}_09], [FG_{DatabaseName}_10], [FG_{DatabaseName}_11], [FG_{DatabaseName}_12])
GO
/****** Object:  Table [dbo].[AlarmControlHistory]    Script Date: 18/04 11:23:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AlarmControlHistory](
	[ID] [uniqueidentifier] NOT NULL,
	[CreateTime] [datetime] NOT NULL,
	[IDDevice] [uniqueidentifier] NULL,
	[CopyID] [int] NOT NULL,
	[CopyIDDevice] [int] NOT NULL,
	[CopyAlarmHigh] [nvarchar](100) NOT NULL,
	[CopyAlarmLow] [nvarchar](100) NOT NULL,
	[CopyAlarmAPS] [nvarchar](100) NOT NULL,
	[CopyControlDevice] [int] NULL,
	[CopyCalib] [nvarchar](100) NULL,
	[Copydate_time] [datetime] NULL,
 CONSTRAINT [PK__AlarmCon__3214EC27FB1CD07F] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CommentMeasureData]    Script Date: 18/04 11:23:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CommentMeasureData](
	[ID] [uniqueidentifier] NOT NULL,
	[FromTime] [datetime] NOT NULL,
	[ToTime] [datetime] NOT NULL,
	[Comment] [nvarchar](1000) NULL,
	[IDDevice] [uniqueidentifier] NULL,
	[DevicePosition] [nvarchar](50) NULL,
	[UpdateTime] [datetime] NULL,
	[IsDelete] [bit] NULL,
	[CommentBy] [nvarchar](50) NULL,
 CONSTRAINT [PK_CommentMeasueData] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ConnectionHistory]    Script Date: 18/04 11:23:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ConnectionHistory](
	[ID] [uniqueidentifier] NOT NULL,
	[CreateTime] [datetime] NOT NULL,
	[Message] [nvarchar](max) NULL,
	[CopyTimerConnect] [nvarchar](100) NOT NULL,
	[CopyModScan] [nvarchar](100) NOT NULL,
 CONSTRAINT [PK__Connecti__3214EC2771C305A2] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[MeasureData]    Script Date: 18/04 11:23:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[MeasureData](
	[ID] [uniqueidentifier] NOT NULL,
	[CreateTime] [datetime] NOT NULL,
	[IDDevice] [uniqueidentifier] NULL,
	[RawValue] [nvarchar](100) NULL,
	[Value] [float] NULL,
	[APSValue] [float] NULL,
	[Central] [nvarchar](100) NULL,
	[AO_Alarm] [int] NULL,
	[AG_Alarm] [int] NULL,
	[APS_Alarm] [int] NULL,
	[UW_Alarm] [int] NULL,
	[LockControlState1] [int] NULL,
	[LockControlState2] [int] NULL,
	[CalibMode] [int] NULL,
	[ChartCase] [int] NULL,
	[InputValue] [nvarchar](50) NULL,
 CONSTRAINT [PK__MeasureD__3214EC27E1AF5FDC] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Index [NonClusteredIndex-AlarmControlHistory-PartitionBymonth]    Script Date: 18/04 11:23:18 ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-AlarmControlHistory-PartitionBymonth] ON [dbo].[AlarmControlHistory]
(
	[CreateTime] ASC,
	[IDDevice] ASC
)
INCLUDE([ID],[CopyID],[CopyIDDevice],[CopyAlarmHigh],[CopyAlarmLow],[CopyAlarmAPS],[CopyControlDevice],[CopyCalib],[Copydate_time]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PartitionBymonth]([CreateTime])
GO
/****** Object:  Index [NonClusteredIndex-CommentMeasureData-PartitionBymonth]    Script Date: 18/04 11:23:18 ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-CommentMeasureData-PartitionBymonth] ON [dbo].[CommentMeasureData]
(
	[FromTime] ASC,
	[ToTime] ASC,
	[IDDevice] ASC
)
INCLUDE([ID],[Comment],[DevicePosition],[UpdateTime],[IsDelete],[CommentBy]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PartitionBymonth]([FromTime])
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-ConnectionHistory-PartitionBymonth]    Script Date: 18/04 11:23:18 ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-ConnectionHistory-PartitionBymonth] ON [dbo].[ConnectionHistory]
(
	[CreateTime] ASC,
	[ID] ASC,
	[CopyTimerConnect] ASC,
	[CopyModScan] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PartitionBymonth]([CreateTime])
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-MeasureData-PartitionBymonth]    Script Date: 18/04 11:23:18 ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-MeasureData-PartitionBymonth] ON [dbo].[MeasureData]
(
	[CreateTime] ASC,
	[IDDevice] ASC,
	[Central] ASC
)
INCLUDE([RawValue],[Value],[APSValue],[CalibMode],[ChartCase],[InputValue],[AO_Alarm],[AG_Alarm],[APS_Alarm],[UW_Alarm],[LockControlState1],[LockControlState2]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PartitionBymonth]([CreateTime])
GO
ALTER TABLE [dbo].[AlarmControlHistory] ADD  CONSTRAINT [DF__AlarmCont__CopyC__3D5E1FD2]  DEFAULT (N'0') FOR [CopyControlDevice]
GO
ALTER TABLE [dbo].[AlarmControlHistory] ADD  CONSTRAINT [DF__AlarmCont__CopyC__3E52440B]  DEFAULT (N'0') FOR [CopyCalib]
GO
ALTER TABLE [dbo].[AlarmControlHistory] ADD  CONSTRAINT [DF__AlarmCont__Copyd__3F466844]  DEFAULT (getdate()) FOR [Copydate_time]
GO
ALTER TABLE [dbo].[ConnectionHistory] ADD  CONSTRAINT [DF__Connectio__CopyM__403A8C7D]  DEFAULT (N'C') FOR [CopyModScan]
GO
USE [master]
GO
ALTER DATABASE [{DatabaseName}] SET  READ_WRITE 
GO
