﻿//https://openlayers.org/en/latest/examples/static-image.html

//    const extent = [0, 0, 1024, 968];
//    const projection = new ol.proj.Projection({
//        code: 'xkcd-image',
//        units: 'pixels',
//        extent: extent,
//    });

//    const map = new ol.Map({
//        layers: [
//            new ol.layer.Image({
//                source: new ol.source.ImageStatic({
//                    url: '/file?path=Views/map/map.png&type=image/png',
//                    projection: projection,
//                    imageExtent: extent,
//                }),
//            }),
//        ],
//        target: 'map',
//        view: new ol.View({
//            projection: projection,
//            center: ol.extent.getCenter(extent),
//            zoom: 2,
//            maxZoom: 8,
//        }),
//    });