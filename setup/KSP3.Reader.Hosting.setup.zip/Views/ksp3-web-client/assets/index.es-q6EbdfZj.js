(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const i of document.querySelectorAll('link[rel="modulepreload"]'))r(i);new MutationObserver(i=>{for(const a of i)if(a.type==="childList")for(const o of a.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&r(o)}).observe(document,{childList:!0,subtree:!0});function n(i){const a={};return i.integrity&&(a.integrity=i.integrity),i.referrerPolicy&&(a.referrerPolicy=i.referrerPolicy),i.crossOrigin==="use-credentials"?a.credentials="include":i.crossOrigin==="anonymous"?a.credentials="omit":a.credentials="same-origin",a}function r(i){if(i.ep)return;i.ep=!0;const a=n(i);fetch(i.href,a)}})();/**
* @vue/shared v3.4.27
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**//*! #__NO_SIDE_EFFECTS__ */function Ur(t,e){const n=new Set(t.split(","));return r=>n.has(r)}const V={},ye=[],bt=()=>{},cs=()=>!1,$n=t=>t.charCodeAt(0)===111&&t.charCodeAt(1)===110&&(t.charCodeAt(2)>122||t.charCodeAt(2)<97),Hr=t=>t.startsWith("onUpdate:"),rt=Object.assign,Br=(t,e)=>{const n=t.indexOf(e);n>-1&&t.splice(n,1)},us=Object.prototype.hasOwnProperty,z=(t,e)=>us.call(t,e),M=Array.isArray,xe=t=>zn(t)==="[object Map]",Na=t=>zn(t)==="[object Set]",F=t=>typeof t=="function",tt=t=>typeof t=="string",he=t=>typeof t=="symbol",q=t=>t!==null&&typeof t=="object",Ma=t=>(q(t)||F(t))&&F(t.then)&&F(t.catch),Ra=Object.prototype.toString,zn=t=>Ra.call(t),ds=t=>zn(t).slice(8,-1),La=t=>zn(t)==="[object Object]",Yr=t=>tt(t)&&t!=="NaN"&&t[0]!=="-"&&""+parseInt(t,10)===t,Re=Ur(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),Un=t=>{const e=Object.create(null);return n=>e[n]||(e[n]=t(n))},ms=/-(\w)/g,It=Un(t=>t.replace(ms,(e,n)=>n?n.toUpperCase():"")),hs=/\B([A-Z])/g,ke=Un(t=>t.replace(hs,"-$1").toLowerCase()),Hn=Un(t=>t.charAt(0).toUpperCase()+t.slice(1)),nr=Un(t=>t?`on${Hn(t)}`:""),Gt=(t,e)=>!Object.is(t,e),wn=(t,e)=>{for(let n=0;n<t.length;n++)t[n](e)},Fa=(t,e,n,r=!1)=>{Object.defineProperty(t,e,{configurable:!0,enumerable:!1,writable:r,value:n})},gr=t=>{const e=parseFloat(t);return isNaN(e)?t:e};let Si;const ja=()=>Si||(Si=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function Wr(t){if(M(t)){const e={};for(let n=0;n<t.length;n++){const r=t[n],i=tt(r)?bs(r):Wr(r);if(i)for(const a in i)e[a]=i[a]}return e}else if(tt(t)||q(t))return t}const ps=/;(?![^(]*\))/g,gs=/:([^]+)/,vs=/\/\*[^]*?\*\//g;function bs(t){const e={};return t.replace(vs,"").split(ps).forEach(n=>{if(n){const r=n.split(gs);r.length>1&&(e[r[0].trim()]=r[1].trim())}}),e}function Vr(t){let e="";if(tt(t))e=t;else if(M(t))for(let n=0;n<t.length;n++){const r=Vr(t[n]);r&&(e+=r+" ")}else if(q(t))for(const n in t)t[n]&&(e+=n+" ");return e.trim()}const ys="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",xs=Ur(ys);function Da(t){return!!t||t===""}const Pu=t=>tt(t)?t:t==null?"":M(t)||q(t)&&(t.toString===Ra||!F(t.toString))?JSON.stringify(t,$a,2):String(t),$a=(t,e)=>e&&e.__v_isRef?$a(t,e.value):xe(e)?{[`Map(${e.size})`]:[...e.entries()].reduce((n,[r,i],a)=>(n[rr(r,a)+" =>"]=i,n),{})}:Na(e)?{[`Set(${e.size})`]:[...e.values()].map(n=>rr(n))}:he(e)?rr(e):q(e)&&!M(e)&&!La(e)?String(e):e,rr=(t,e="")=>{var n;return he(t)?`Symbol(${(n=t.description)!=null?n:e})`:t};/**
* @vue/reactivity v3.4.27
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let xt;class ws{constructor(e=!1){this.detached=e,this._active=!0,this.effects=[],this.cleanups=[],this.parent=xt,!e&&xt&&(this.index=(xt.scopes||(xt.scopes=[])).push(this)-1)}get active(){return this._active}run(e){if(this._active){const n=xt;try{return xt=this,e()}finally{xt=n}}}on(){xt=this}off(){xt=this.parent}stop(e){if(this._active){let n,r;for(n=0,r=this.effects.length;n<r;n++)this.effects[n].stop();for(n=0,r=this.cleanups.length;n<r;n++)this.cleanups[n]();if(this.scopes)for(n=0,r=this.scopes.length;n<r;n++)this.scopes[n].stop(!0);if(!this.detached&&this.parent&&!e){const i=this.parent.scopes.pop();i&&i!==this&&(this.parent.scopes[this.index]=i,i.index=this.index)}this.parent=void 0,this._active=!1}}}function _s(t,e=xt){e&&e.active&&e.effects.push(t)}function As(){return xt}let fe;class Kr{constructor(e,n,r,i){this.fn=e,this.trigger=n,this.scheduler=r,this.active=!0,this.deps=[],this._dirtyLevel=4,this._trackId=0,this._runnings=0,this._shouldSchedule=!1,this._depsLength=0,_s(this,i)}get dirty(){if(this._dirtyLevel===2||this._dirtyLevel===3){this._dirtyLevel=1,Zt();for(let e=0;e<this._depsLength;e++){const n=this.deps[e];if(n.computed&&(Os(n.computed),this._dirtyLevel>=4))break}this._dirtyLevel===1&&(this._dirtyLevel=0),Qt()}return this._dirtyLevel>=4}set dirty(e){this._dirtyLevel=e?4:0}run(){if(this._dirtyLevel=0,!this.active)return this.fn();let e=Vt,n=fe;try{return Vt=!0,fe=this,this._runnings++,Pi(this),this.fn()}finally{Ci(this),this._runnings--,fe=n,Vt=e}}stop(){this.active&&(Pi(this),Ci(this),this.onStop&&this.onStop(),this.active=!1)}}function Os(t){return t.value}function Pi(t){t._trackId++,t._depsLength=0}function Ci(t){if(t.deps.length>t._depsLength){for(let e=t._depsLength;e<t.deps.length;e++)za(t.deps[e],t);t.deps.length=t._depsLength}}function za(t,e){const n=t.get(e);n!==void 0&&e._trackId!==n&&(t.delete(e),t.size===0&&t.cleanup())}let Vt=!0,vr=0;const Ua=[];function Zt(){Ua.push(Vt),Vt=!1}function Qt(){const t=Ua.pop();Vt=t===void 0?!0:t}function Gr(){vr++}function Xr(){for(vr--;!vr&&br.length;)br.shift()()}function Ha(t,e,n){if(e.get(t)!==t._trackId){e.set(t,t._trackId);const r=t.deps[t._depsLength];r!==e?(r&&za(r,t),t.deps[t._depsLength++]=e):t._depsLength++}}const br=[];function Ba(t,e,n){Gr();for(const r of t.keys()){let i;r._dirtyLevel<e&&(i??(i=t.get(r)===r._trackId))&&(r._shouldSchedule||(r._shouldSchedule=r._dirtyLevel===0),r._dirtyLevel=e),r._shouldSchedule&&(i??(i=t.get(r)===r._trackId))&&(r.trigger(),(!r._runnings||r.allowRecurse)&&r._dirtyLevel!==2&&(r._shouldSchedule=!1,r.scheduler&&br.push(r.scheduler)))}Xr()}const Ya=(t,e)=>{const n=new Map;return n.cleanup=t,n.computed=e,n},yr=new WeakMap,ce=Symbol(""),xr=Symbol("");function dt(t,e,n){if(Vt&&fe){let r=yr.get(t);r||yr.set(t,r=new Map);let i=r.get(n);i||r.set(n,i=Ya(()=>r.delete(n))),Ha(fe,i)}}function Lt(t,e,n,r,i,a){const o=yr.get(t);if(!o)return;let s=[];if(e==="clear")s=[...o.values()];else if(n==="length"&&M(t)){const l=Number(r);o.forEach((c,u)=>{(u==="length"||!he(u)&&u>=l)&&s.push(c)})}else switch(n!==void 0&&s.push(o.get(n)),e){case"add":M(t)?Yr(n)&&s.push(o.get("length")):(s.push(o.get(ce)),xe(t)&&s.push(o.get(xr)));break;case"delete":M(t)||(s.push(o.get(ce)),xe(t)&&s.push(o.get(xr)));break;case"set":xe(t)&&s.push(o.get(ce));break}Gr();for(const l of s)l&&Ba(l,4);Xr()}const ks=Ur("__proto__,__v_isRef,__isVue"),Wa=new Set(Object.getOwnPropertyNames(Symbol).filter(t=>t!=="arguments"&&t!=="caller").map(t=>Symbol[t]).filter(he)),Ii=Es();function Es(){const t={};return["includes","indexOf","lastIndexOf"].forEach(e=>{t[e]=function(...n){const r=H(this);for(let a=0,o=this.length;a<o;a++)dt(r,"get",a+"");const i=r[e](...n);return i===-1||i===!1?r[e](...n.map(H)):i}}),["push","pop","shift","unshift","splice"].forEach(e=>{t[e]=function(...n){Zt(),Gr();const r=H(this)[e].apply(this,n);return Xr(),Qt(),r}}),t}function Ss(t){he(t)||(t=String(t));const e=H(this);return dt(e,"has",t),e.hasOwnProperty(t)}class Va{constructor(e=!1,n=!1){this._isReadonly=e,this._isShallow=n}get(e,n,r){const i=this._isReadonly,a=this._isShallow;if(n==="__v_isReactive")return!i;if(n==="__v_isReadonly")return i;if(n==="__v_isShallow")return a;if(n==="__v_raw")return r===(i?a?zs:qa:a?Xa:Ga).get(e)||Object.getPrototypeOf(e)===Object.getPrototypeOf(r)?e:void 0;const o=M(e);if(!i){if(o&&z(Ii,n))return Reflect.get(Ii,n,r);if(n==="hasOwnProperty")return Ss}const s=Reflect.get(e,n,r);return(he(n)?Wa.has(n):ks(n))||(i||dt(e,"get",n),a)?s:mt(s)?o&&Yr(n)?s:s.value:q(s)?i?Ja(s):Zr(s):s}}class Ka extends Va{constructor(e=!1){super(!1,e)}set(e,n,r,i){let a=e[n];if(!this._isShallow){const l=Ue(a);if(!In(r)&&!Ue(r)&&(a=H(a),r=H(r)),!M(e)&&mt(a)&&!mt(r))return l?!1:(a.value=r,!0)}const o=M(e)&&Yr(n)?Number(n)<e.length:z(e,n),s=Reflect.set(e,n,r,i);return e===H(i)&&(o?Gt(r,a)&&Lt(e,"set",n,r):Lt(e,"add",n,r)),s}deleteProperty(e,n){const r=z(e,n);e[n];const i=Reflect.deleteProperty(e,n);return i&&r&&Lt(e,"delete",n,void 0),i}has(e,n){const r=Reflect.has(e,n);return(!he(n)||!Wa.has(n))&&dt(e,"has",n),r}ownKeys(e){return dt(e,"iterate",M(e)?"length":ce),Reflect.ownKeys(e)}}class Ps extends Va{constructor(e=!1){super(!0,e)}set(e,n){return!0}deleteProperty(e,n){return!0}}const Cs=new Ka,Is=new Ps,Ts=new Ka(!0);const qr=t=>t,Bn=t=>Reflect.getPrototypeOf(t);function on(t,e,n=!1,r=!1){t=t.__v_raw;const i=H(t),a=H(e);n||(Gt(e,a)&&dt(i,"get",e),dt(i,"get",a));const{has:o}=Bn(i),s=r?qr:n?ti:He;if(o.call(i,e))return s(t.get(e));if(o.call(i,a))return s(t.get(a));t!==i&&t.get(e)}function sn(t,e=!1){const n=this.__v_raw,r=H(n),i=H(t);return e||(Gt(t,i)&&dt(r,"has",t),dt(r,"has",i)),t===i?n.has(t):n.has(t)||n.has(i)}function ln(t,e=!1){return t=t.__v_raw,!e&&dt(H(t),"iterate",ce),Reflect.get(t,"size",t)}function Ti(t){t=H(t);const e=H(this);return Bn(e).has.call(e,t)||(e.add(t),Lt(e,"add",t,t)),this}function Ni(t,e){e=H(e);const n=H(this),{has:r,get:i}=Bn(n);let a=r.call(n,t);a||(t=H(t),a=r.call(n,t));const o=i.call(n,t);return n.set(t,e),a?Gt(e,o)&&Lt(n,"set",t,e):Lt(n,"add",t,e),this}function Mi(t){const e=H(this),{has:n,get:r}=Bn(e);let i=n.call(e,t);i||(t=H(t),i=n.call(e,t)),r&&r.call(e,t);const a=e.delete(t);return i&&Lt(e,"delete",t,void 0),a}function Ri(){const t=H(this),e=t.size!==0,n=t.clear();return e&&Lt(t,"clear",void 0,void 0),n}function fn(t,e){return function(r,i){const a=this,o=a.__v_raw,s=H(o),l=e?qr:t?ti:He;return!t&&dt(s,"iterate",ce),o.forEach((c,u)=>r.call(i,l(c),l(u),a))}}function cn(t,e,n){return function(...r){const i=this.__v_raw,a=H(i),o=xe(a),s=t==="entries"||t===Symbol.iterator&&o,l=t==="keys"&&o,c=i[t](...r),u=n?qr:e?ti:He;return!e&&dt(a,"iterate",l?xr:ce),{next(){const{value:m,done:v}=c.next();return v?{value:m,done:v}:{value:s?[u(m[0]),u(m[1])]:u(m),done:v}},[Symbol.iterator](){return this}}}}function Ut(t){return function(...e){return t==="delete"?!1:t==="clear"?void 0:this}}function Ns(){const t={get(a){return on(this,a)},get size(){return ln(this)},has:sn,add:Ti,set:Ni,delete:Mi,clear:Ri,forEach:fn(!1,!1)},e={get(a){return on(this,a,!1,!0)},get size(){return ln(this)},has:sn,add:Ti,set:Ni,delete:Mi,clear:Ri,forEach:fn(!1,!0)},n={get(a){return on(this,a,!0)},get size(){return ln(this,!0)},has(a){return sn.call(this,a,!0)},add:Ut("add"),set:Ut("set"),delete:Ut("delete"),clear:Ut("clear"),forEach:fn(!0,!1)},r={get(a){return on(this,a,!0,!0)},get size(){return ln(this,!0)},has(a){return sn.call(this,a,!0)},add:Ut("add"),set:Ut("set"),delete:Ut("delete"),clear:Ut("clear"),forEach:fn(!0,!0)};return["keys","values","entries",Symbol.iterator].forEach(a=>{t[a]=cn(a,!1,!1),n[a]=cn(a,!0,!1),e[a]=cn(a,!1,!0),r[a]=cn(a,!0,!0)}),[t,n,e,r]}const[Ms,Rs,Ls,Fs]=Ns();function Jr(t,e){const n=e?t?Fs:Ls:t?Rs:Ms;return(r,i,a)=>i==="__v_isReactive"?!t:i==="__v_isReadonly"?t:i==="__v_raw"?r:Reflect.get(z(n,i)&&i in r?n:r,i,a)}const js={get:Jr(!1,!1)},Ds={get:Jr(!1,!0)},$s={get:Jr(!0,!1)};const Ga=new WeakMap,Xa=new WeakMap,qa=new WeakMap,zs=new WeakMap;function Us(t){switch(t){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function Hs(t){return t.__v_skip||!Object.isExtensible(t)?0:Us(ds(t))}function Zr(t){return Ue(t)?t:Qr(t,!1,Cs,js,Ga)}function Bs(t){return Qr(t,!1,Ts,Ds,Xa)}function Ja(t){return Qr(t,!0,Is,$s,qa)}function Qr(t,e,n,r,i){if(!q(t)||t.__v_raw&&!(e&&t.__v_isReactive))return t;const a=i.get(t);if(a)return a;const o=Hs(t);if(o===0)return t;const s=new Proxy(t,o===2?r:n);return i.set(t,s),s}function Le(t){return Ue(t)?Le(t.__v_raw):!!(t&&t.__v_isReactive)}function Ue(t){return!!(t&&t.__v_isReadonly)}function In(t){return!!(t&&t.__v_isShallow)}function Za(t){return t?!!t.__v_raw:!1}function H(t){const e=t&&t.__v_raw;return e?H(e):t}function Ys(t){return Object.isExtensible(t)&&Fa(t,"__v_skip",!0),t}const He=t=>q(t)?Zr(t):t,ti=t=>q(t)?Ja(t):t;class Qa{constructor(e,n,r,i){this.getter=e,this._setter=n,this.dep=void 0,this.__v_isRef=!0,this.__v_isReadonly=!1,this.effect=new Kr(()=>e(this._value),()=>_n(this,this.effect._dirtyLevel===2?2:3)),this.effect.computed=this,this.effect.active=this._cacheable=!i,this.__v_isReadonly=r}get value(){const e=H(this);return(!e._cacheable||e.effect.dirty)&&Gt(e._value,e._value=e.effect.run())&&_n(e,4),to(e),e.effect._dirtyLevel>=2&&_n(e,2),e._value}set value(e){this._setter(e)}get _dirty(){return this.effect.dirty}set _dirty(e){this.effect.dirty=e}}function Ws(t,e,n=!1){let r,i;const a=F(t);return a?(r=t,i=bt):(r=t.get,i=t.set),new Qa(r,i,a||!i,n)}function to(t){var e;Vt&&fe&&(t=H(t),Ha(fe,(e=t.dep)!=null?e:t.dep=Ya(()=>t.dep=void 0,t instanceof Qa?t:void 0)))}function _n(t,e=4,n){t=H(t);const r=t.dep;r&&Ba(r,e)}function mt(t){return!!(t&&t.__v_isRef===!0)}function Cu(t){return Vs(t,!1)}function Vs(t,e){return mt(t)?t:new Ks(t,e)}class Ks{constructor(e,n){this.__v_isShallow=n,this.dep=void 0,this.__v_isRef=!0,this._rawValue=n?e:H(e),this._value=n?e:He(e)}get value(){return to(this),this._value}set value(e){const n=this.__v_isShallow||In(e)||Ue(e);e=n?e:H(e),Gt(e,this._rawValue)&&(this._rawValue=e,this._value=n?e:He(e),_n(this,4))}}function Gs(t){return mt(t)?t.value:t}const Xs={get:(t,e,n)=>Gs(Reflect.get(t,e,n)),set:(t,e,n,r)=>{const i=t[e];return mt(i)&&!mt(n)?(i.value=n,!0):Reflect.set(t,e,n,r)}};function eo(t){return Le(t)?t:new Proxy(t,Xs)}/**
* @vue/runtime-core v3.4.27
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Kt(t,e,n,r){try{return r?t(...r):t()}catch(i){Yn(i,e,n)}}function At(t,e,n,r){if(F(t)){const i=Kt(t,e,n,r);return i&&Ma(i)&&i.catch(a=>{Yn(a,e,n)}),i}if(M(t)){const i=[];for(let a=0;a<t.length;a++)i.push(At(t[a],e,n,r));return i}}function Yn(t,e,n,r=!0){const i=e?e.vnode:null;if(e){let a=e.parent;const o=e.proxy,s=`https://vuejs.org/error-reference/#runtime-${n}`;for(;a;){const c=a.ec;if(c){for(let u=0;u<c.length;u++)if(c[u](t,o,s)===!1)return}a=a.parent}const l=e.appContext.config.errorHandler;if(l){Zt(),Kt(l,null,10,[t,o,s]),Qt();return}}qs(t,n,i,r)}function qs(t,e,n,r=!0){console.error(t)}let Be=!1,wr=!1;const it=[];let Pt=0;const we=[];let Bt=null,ae=0;const no=Promise.resolve();let ei=null;function Js(t){const e=ei||no;return t?e.then(this?t.bind(this):t):e}function Zs(t){let e=Pt+1,n=it.length;for(;e<n;){const r=e+n>>>1,i=it[r],a=Ye(i);a<t||a===t&&i.pre?e=r+1:n=r}return e}function ni(t){(!it.length||!it.includes(t,Be&&t.allowRecurse?Pt+1:Pt))&&(t.id==null?it.push(t):it.splice(Zs(t.id),0,t),ro())}function ro(){!Be&&!wr&&(wr=!0,ei=no.then(ao))}function Qs(t){const e=it.indexOf(t);e>Pt&&it.splice(e,1)}function tl(t){M(t)?we.push(...t):(!Bt||!Bt.includes(t,t.allowRecurse?ae+1:ae))&&we.push(t),ro()}function Li(t,e,n=Be?Pt+1:0){for(;n<it.length;n++){const r=it[n];if(r&&r.pre){if(t&&r.id!==t.uid)continue;it.splice(n,1),n--,r()}}}function io(t){if(we.length){const e=[...new Set(we)].sort((n,r)=>Ye(n)-Ye(r));if(we.length=0,Bt){Bt.push(...e);return}for(Bt=e,ae=0;ae<Bt.length;ae++)Bt[ae]();Bt=null,ae=0}}const Ye=t=>t.id==null?1/0:t.id,el=(t,e)=>{const n=Ye(t)-Ye(e);if(n===0){if(t.pre&&!e.pre)return-1;if(e.pre&&!t.pre)return 1}return n};function ao(t){wr=!1,Be=!0,it.sort(el);try{for(Pt=0;Pt<it.length;Pt++){const e=it[Pt];e&&e.active!==!1&&Kt(e,null,14)}}finally{Pt=0,it.length=0,io(),Be=!1,ei=null,(it.length||we.length)&&ao()}}function nl(t,e,...n){if(t.isUnmounted)return;const r=t.vnode.props||V;let i=n;const a=e.startsWith("update:"),o=a&&e.slice(7);if(o&&o in r){const u=`${o==="modelValue"?"model":o}Modifiers`,{number:m,trim:v}=r[u]||V;v&&(i=n.map(_=>tt(_)?_.trim():_)),m&&(i=n.map(gr))}let s,l=r[s=nr(e)]||r[s=nr(It(e))];!l&&a&&(l=r[s=nr(ke(e))]),l&&At(l,t,6,i);const c=r[s+"Once"];if(c){if(!t.emitted)t.emitted={};else if(t.emitted[s])return;t.emitted[s]=!0,At(c,t,6,i)}}function oo(t,e,n=!1){const r=e.emitsCache,i=r.get(t);if(i!==void 0)return i;const a=t.emits;let o={},s=!1;if(!F(t)){const l=c=>{const u=oo(c,e,!0);u&&(s=!0,rt(o,u))};!n&&e.mixins.length&&e.mixins.forEach(l),t.extends&&l(t.extends),t.mixins&&t.mixins.forEach(l)}return!a&&!s?(q(t)&&r.set(t,null),null):(M(a)?a.forEach(l=>o[l]=null):rt(o,a),q(t)&&r.set(t,o),o)}function Wn(t,e){return!t||!$n(e)?!1:(e=e.slice(2).replace(/Once$/,""),z(t,e[0].toLowerCase()+e.slice(1))||z(t,ke(e))||z(t,e))}let ut=null,so=null;function Tn(t){const e=ut;return ut=t,so=t&&t.type.__scopeId||null,e}function rl(t,e=ut,n){if(!e||t._n)return t;const r=(...i)=>{r._d&&Vi(-1);const a=Tn(e);let o;try{o=t(...i)}finally{Tn(a),r._d&&Vi(1)}return o};return r._n=!0,r._c=!0,r._d=!0,r}function ir(t){const{type:e,vnode:n,proxy:r,withProxy:i,propsOptions:[a],slots:o,attrs:s,emit:l,render:c,renderCache:u,props:m,data:v,setupState:_,ctx:j,inheritAttrs:N}=t,B=Tn(t);let A,k;try{if(n.shapeFlag&4){const D=i||r,U=D;A=St(c.call(U,D,u,m,_,v,j)),k=s}else{const D=e;A=St(D.length>1?D(m,{attrs:s,slots:o,emit:l}):D(m,null)),k=e.props?s:il(s)}}catch(D){De.length=0,Yn(D,t,1),A=pt(ue)}let C=A;if(k&&N!==!1){const D=Object.keys(k),{shapeFlag:U}=C;D.length&&U&7&&(a&&D.some(Hr)&&(k=al(k,a)),C=Ae(C,k,!1,!0))}return n.dirs&&(C=Ae(C,null,!1,!0),C.dirs=C.dirs?C.dirs.concat(n.dirs):n.dirs),n.transition&&(C.transition=n.transition),A=C,Tn(B),A}const il=t=>{let e;for(const n in t)(n==="class"||n==="style"||$n(n))&&((e||(e={}))[n]=t[n]);return e},al=(t,e)=>{const n={};for(const r in t)(!Hr(r)||!(r.slice(9)in e))&&(n[r]=t[r]);return n};function ol(t,e,n){const{props:r,children:i,component:a}=t,{props:o,children:s,patchFlag:l}=e,c=a.emitsOptions;if(e.dirs||e.transition)return!0;if(n&&l>=0){if(l&1024)return!0;if(l&16)return r?Fi(r,o,c):!!o;if(l&8){const u=e.dynamicProps;for(let m=0;m<u.length;m++){const v=u[m];if(o[v]!==r[v]&&!Wn(c,v))return!0}}}else return(i||s)&&(!s||!s.$stable)?!0:r===o?!1:r?o?Fi(r,o,c):!0:!!o;return!1}function Fi(t,e,n){const r=Object.keys(e);if(r.length!==Object.keys(t).length)return!0;for(let i=0;i<r.length;i++){const a=r[i];if(e[a]!==t[a]&&!Wn(n,a))return!0}return!1}function sl({vnode:t,parent:e},n){for(;e;){const r=e.subTree;if(r.suspense&&r.suspense.activeBranch===t&&(r.el=t.el),r===t)(t=e.vnode).el=n,e=e.parent;else break}}const ll="components";function Iu(t,e){return cl(ll,t,!0,e)||t}const fl=Symbol.for("v-ndc");function cl(t,e,n=!0,r=!1){const i=ut||at;if(i){const a=i.type;{const s=ff(a,!1);if(s&&(s===e||s===It(e)||s===Hn(It(e))))return a}const o=ji(i[t]||a[t],e)||ji(i.appContext[t],e);return!o&&r?a:o}}function ji(t,e){return t&&(t[e]||t[It(e)]||t[Hn(It(e))])}const ul=t=>t.__isSuspense;function dl(t,e){e&&e.pendingBranch?M(t)?e.effects.push(...t):e.effects.push(t):tl(t)}const ml=Symbol.for("v-scx"),hl=()=>kn(ml),un={};function An(t,e,n){return lo(t,e,n)}function lo(t,e,{immediate:n,deep:r,flush:i,once:a,onTrack:o,onTrigger:s}=V){if(e&&a){const L=e;e=(...Q)=>{L(...Q),U()}}const l=at,c=L=>r===!0?L:oe(L,r===!1?1:void 0);let u,m=!1,v=!1;if(mt(t)?(u=()=>t.value,m=In(t)):Le(t)?(u=()=>c(t),m=!0):M(t)?(v=!0,m=t.some(L=>Le(L)||In(L)),u=()=>t.map(L=>{if(mt(L))return L.value;if(Le(L))return c(L);if(F(L))return Kt(L,l,2)})):F(t)?e?u=()=>Kt(t,l,2):u=()=>(_&&_(),At(t,l,3,[j])):u=bt,e&&r){const L=u;u=()=>oe(L())}let _,j=L=>{_=C.onStop=()=>{Kt(L,l,4),_=C.onStop=void 0}},N;if(Gn)if(j=bt,e?n&&At(e,l,3,[u(),v?[]:void 0,j]):u(),i==="sync"){const L=hl();N=L.__watcherHandles||(L.__watcherHandles=[])}else return bt;let B=v?new Array(t.length).fill(un):un;const A=()=>{if(!(!C.active||!C.dirty))if(e){const L=C.run();(r||m||(v?L.some((Q,lt)=>Gt(Q,B[lt])):Gt(L,B)))&&(_&&_(),At(e,l,3,[L,B===un?void 0:v&&B[0]===un?[]:B,j]),B=L)}else C.run()};A.allowRecurse=!!e;let k;i==="sync"?k=A:i==="post"?k=()=>ct(A,l&&l.suspense):(A.pre=!0,l&&(A.id=l.uid),k=()=>ni(A));const C=new Kr(u,bt,k),D=As(),U=()=>{C.stop(),D&&Br(D.effects,C)};return e?n?A():B=C.run():i==="post"?ct(C.run.bind(C),l&&l.suspense):C.run(),N&&N.push(U),U}function pl(t,e,n){const r=this.proxy,i=tt(t)?t.includes(".")?fo(r,t):()=>r[t]:t.bind(r,r);let a;F(e)?a=e:(a=e.handler,n=e);const o=Je(this),s=lo(i,a.bind(r),n);return o(),s}function fo(t,e){const n=e.split(".");return()=>{let r=t;for(let i=0;i<n.length&&r;i++)r=r[n[i]];return r}}function oe(t,e=1/0,n){if(e<=0||!q(t)||t.__v_skip||(n=n||new Set,n.has(t)))return t;if(n.add(t),e--,mt(t))oe(t.value,e,n);else if(M(t))for(let r=0;r<t.length;r++)oe(t[r],e,n);else if(Na(t)||xe(t))t.forEach(r=>{oe(r,e,n)});else if(La(t))for(const r in t)oe(t[r],e,n);return t}function Tu(t,e){if(ut===null)return t;const n=Xn(ut)||ut.proxy,r=t.dirs||(t.dirs=[]);for(let i=0;i<e.length;i++){let[a,o,s,l=V]=e[i];a&&(F(a)&&(a={mounted:a,updated:a}),a.deep&&oe(o),r.push({dir:a,instance:n,value:o,oldValue:void 0,arg:s,modifiers:l}))}return t}function ne(t,e,n,r){const i=t.dirs,a=e&&e.dirs;for(let o=0;o<i.length;o++){const s=i[o];a&&(s.oldValue=a[o].value);let l=s.dir[r];l&&(Zt(),At(l,n,8,[t.el,s,t,e]),Qt())}}/*! #__NO_SIDE_EFFECTS__ */function gl(t,e){return F(t)?rt({name:t.name},e,{setup:t}):t}const On=t=>!!t.type.__asyncLoader,co=t=>t.type.__isKeepAlive;function vl(t,e){uo(t,"a",e)}function bl(t,e){uo(t,"da",e)}function uo(t,e,n=at){const r=t.__wdc||(t.__wdc=()=>{let i=n;for(;i;){if(i.isDeactivated)return;i=i.parent}return t()});if(Vn(e,r,n),n){let i=n.parent;for(;i&&i.parent;)co(i.parent.vnode)&&yl(r,e,n,i),i=i.parent}}function yl(t,e,n,r){const i=Vn(e,t,r,!0);mo(()=>{Br(r[e],i)},n)}function Vn(t,e,n=at,r=!1){if(n){const i=n[t]||(n[t]=[]),a=e.__weh||(e.__weh=(...o)=>{if(n.isUnmounted)return;Zt();const s=Je(n),l=At(e,n,t,o);return s(),Qt(),l});return r?i.unshift(a):i.push(a),a}}const $t=t=>(e,n=at)=>(!Gn||t==="sp")&&Vn(t,(...r)=>e(...r),n),xl=$t("bm"),wl=$t("m"),_l=$t("bu"),Al=$t("u"),Ol=$t("bum"),mo=$t("um"),kl=$t("sp"),El=$t("rtg"),Sl=$t("rtc");function Pl(t,e=at){Vn("ec",t,e)}function Nu(t,e,n,r){let i;const a=n;if(M(t)||tt(t)){i=new Array(t.length);for(let o=0,s=t.length;o<s;o++)i[o]=e(t[o],o,void 0,a)}else if(typeof t=="number"){i=new Array(t);for(let o=0;o<t;o++)i[o]=e(o+1,o,void 0,a)}else if(q(t))if(t[Symbol.iterator])i=Array.from(t,(o,s)=>e(o,s,void 0,a));else{const o=Object.keys(t);i=new Array(o.length);for(let s=0,l=o.length;s<l;s++){const c=o[s];i[s]=e(t[c],c,s,a)}}else i=[];return i}const _r=t=>t?Co(t)?Xn(t)||t.proxy:_r(t.parent):null,Fe=rt(Object.create(null),{$:t=>t,$el:t=>t.vnode.el,$data:t=>t.data,$props:t=>t.props,$attrs:t=>t.attrs,$slots:t=>t.slots,$refs:t=>t.refs,$parent:t=>_r(t.parent),$root:t=>_r(t.root),$emit:t=>t.emit,$options:t=>ri(t),$forceUpdate:t=>t.f||(t.f=()=>{t.effect.dirty=!0,ni(t.update)}),$nextTick:t=>t.n||(t.n=Js.bind(t.proxy)),$watch:t=>pl.bind(t)}),ar=(t,e)=>t!==V&&!t.__isScriptSetup&&z(t,e),Cl={get({_:t},e){if(e==="__v_skip")return!0;const{ctx:n,setupState:r,data:i,props:a,accessCache:o,type:s,appContext:l}=t;let c;if(e[0]!=="$"){const _=o[e];if(_!==void 0)switch(_){case 1:return r[e];case 2:return i[e];case 4:return n[e];case 3:return a[e]}else{if(ar(r,e))return o[e]=1,r[e];if(i!==V&&z(i,e))return o[e]=2,i[e];if((c=t.propsOptions[0])&&z(c,e))return o[e]=3,a[e];if(n!==V&&z(n,e))return o[e]=4,n[e];Ar&&(o[e]=0)}}const u=Fe[e];let m,v;if(u)return e==="$attrs"&&dt(t.attrs,"get",""),u(t);if((m=s.__cssModules)&&(m=m[e]))return m;if(n!==V&&z(n,e))return o[e]=4,n[e];if(v=l.config.globalProperties,z(v,e))return v[e]},set({_:t},e,n){const{data:r,setupState:i,ctx:a}=t;return ar(i,e)?(i[e]=n,!0):r!==V&&z(r,e)?(r[e]=n,!0):z(t.props,e)||e[0]==="$"&&e.slice(1)in t?!1:(a[e]=n,!0)},has({_:{data:t,setupState:e,accessCache:n,ctx:r,appContext:i,propsOptions:a}},o){let s;return!!n[o]||t!==V&&z(t,o)||ar(e,o)||(s=a[0])&&z(s,o)||z(r,o)||z(Fe,o)||z(i.config.globalProperties,o)},defineProperty(t,e,n){return n.get!=null?t._.accessCache[e]=0:z(n,"value")&&this.set(t,e,n.value,null),Reflect.defineProperty(t,e,n)}};function Di(t){return M(t)?t.reduce((e,n)=>(e[n]=null,e),{}):t}let Ar=!0;function Il(t){const e=ri(t),n=t.proxy,r=t.ctx;Ar=!1,e.beforeCreate&&$i(e.beforeCreate,t,"bc");const{data:i,computed:a,methods:o,watch:s,provide:l,inject:c,created:u,beforeMount:m,mounted:v,beforeUpdate:_,updated:j,activated:N,deactivated:B,beforeDestroy:A,beforeUnmount:k,destroyed:C,unmounted:D,render:U,renderTracked:L,renderTriggered:Q,errorCaptured:lt,serverPrefetch:vt,expose:Tt,inheritAttrs:Se,components:en,directives:nn,filters:tr}=e;if(c&&Tl(c,r,null),o)for(const J in o){const W=o[J];F(W)&&(r[J]=W.bind(n))}if(i){const J=i.call(n,n);q(J)&&(t.data=Zr(J))}if(Ar=!0,a)for(const J in a){const W=a[J],te=F(W)?W.bind(n,n):F(W.get)?W.get.bind(n,n):bt,rn=!F(W)&&F(W.set)?W.set.bind(n):bt,ee=ie({get:te,set:rn});Object.defineProperty(r,J,{enumerable:!0,configurable:!0,get:()=>ee.value,set:Ot=>ee.value=Ot})}if(s)for(const J in s)ho(s[J],r,n,J);if(l){const J=F(l)?l.call(n):l;Reflect.ownKeys(J).forEach(W=>{jl(W,J[W])})}u&&$i(u,t,"c");function ot(J,W){M(W)?W.forEach(te=>J(te.bind(n))):W&&J(W.bind(n))}if(ot(xl,m),ot(wl,v),ot(_l,_),ot(Al,j),ot(vl,N),ot(bl,B),ot(Pl,lt),ot(Sl,L),ot(El,Q),ot(Ol,k),ot(mo,D),ot(kl,vt),M(Tt))if(Tt.length){const J=t.exposed||(t.exposed={});Tt.forEach(W=>{Object.defineProperty(J,W,{get:()=>n[W],set:te=>n[W]=te})})}else t.exposed||(t.exposed={});U&&t.render===bt&&(t.render=U),Se!=null&&(t.inheritAttrs=Se),en&&(t.components=en),nn&&(t.directives=nn)}function Tl(t,e,n=bt){M(t)&&(t=Or(t));for(const r in t){const i=t[r];let a;q(i)?"default"in i?a=kn(i.from||r,i.default,!0):a=kn(i.from||r):a=kn(i),mt(a)?Object.defineProperty(e,r,{enumerable:!0,configurable:!0,get:()=>a.value,set:o=>a.value=o}):e[r]=a}}function $i(t,e,n){At(M(t)?t.map(r=>r.bind(e.proxy)):t.bind(e.proxy),e,n)}function ho(t,e,n,r){const i=r.includes(".")?fo(n,r):()=>n[r];if(tt(t)){const a=e[t];F(a)&&An(i,a)}else if(F(t))An(i,t.bind(n));else if(q(t))if(M(t))t.forEach(a=>ho(a,e,n,r));else{const a=F(t.handler)?t.handler.bind(n):e[t.handler];F(a)&&An(i,a,t)}}function ri(t){const e=t.type,{mixins:n,extends:r}=e,{mixins:i,optionsCache:a,config:{optionMergeStrategies:o}}=t.appContext,s=a.get(e);let l;return s?l=s:!i.length&&!n&&!r?l=e:(l={},i.length&&i.forEach(c=>Nn(l,c,o,!0)),Nn(l,e,o)),q(e)&&a.set(e,l),l}function Nn(t,e,n,r=!1){const{mixins:i,extends:a}=e;a&&Nn(t,a,n,!0),i&&i.forEach(o=>Nn(t,o,n,!0));for(const o in e)if(!(r&&o==="expose")){const s=Nl[o]||n&&n[o];t[o]=s?s(t[o],e[o]):e[o]}return t}const Nl={data:zi,props:Ui,emits:Ui,methods:Ne,computed:Ne,beforeCreate:st,created:st,beforeMount:st,mounted:st,beforeUpdate:st,updated:st,beforeDestroy:st,beforeUnmount:st,destroyed:st,unmounted:st,activated:st,deactivated:st,errorCaptured:st,serverPrefetch:st,components:Ne,directives:Ne,watch:Rl,provide:zi,inject:Ml};function zi(t,e){return e?t?function(){return rt(F(t)?t.call(this,this):t,F(e)?e.call(this,this):e)}:e:t}function Ml(t,e){return Ne(Or(t),Or(e))}function Or(t){if(M(t)){const e={};for(let n=0;n<t.length;n++)e[t[n]]=t[n];return e}return t}function st(t,e){return t?[...new Set([].concat(t,e))]:e}function Ne(t,e){return t?rt(Object.create(null),t,e):e}function Ui(t,e){return t?M(t)&&M(e)?[...new Set([...t,...e])]:rt(Object.create(null),Di(t),Di(e??{})):e}function Rl(t,e){if(!t)return e;if(!e)return t;const n=rt(Object.create(null),t);for(const r in e)n[r]=st(t[r],e[r]);return n}function po(){return{app:null,config:{isNativeTag:cs,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let Ll=0;function Fl(t,e){return function(r,i=null){F(r)||(r=rt({},r)),i!=null&&!q(i)&&(i=null);const a=po(),o=new WeakSet;let s=!1;const l=a.app={_uid:Ll++,_component:r,_props:i,_container:null,_context:a,_instance:null,version:df,get config(){return a.config},set config(c){},use(c,...u){return o.has(c)||(c&&F(c.install)?(o.add(c),c.install(l,...u)):F(c)&&(o.add(c),c(l,...u))),l},mixin(c){return a.mixins.includes(c)||a.mixins.push(c),l},component(c,u){return u?(a.components[c]=u,l):a.components[c]},directive(c,u){return u?(a.directives[c]=u,l):a.directives[c]},mount(c,u,m){if(!s){const v=pt(r,i);return v.appContext=a,m===!0?m="svg":m===!1&&(m=void 0),u&&e?e(v,c):t(v,c,m),s=!0,l._container=c,c.__vue_app__=l,Xn(v.component)||v.component.proxy}},unmount(){s&&(t(null,l._container),delete l._container.__vue_app__)},provide(c,u){return a.provides[c]=u,l},runWithContext(c){const u=je;je=l;try{return c()}finally{je=u}}};return l}}let je=null;function jl(t,e){if(at){let n=at.provides;const r=at.parent&&at.parent.provides;r===n&&(n=at.provides=Object.create(r)),n[t]=e}}function kn(t,e,n=!1){const r=at||ut;if(r||je){const i=r?r.parent==null?r.vnode.appContext&&r.vnode.appContext.provides:r.parent.provides:je._context.provides;if(i&&t in i)return i[t];if(arguments.length>1)return n&&F(e)?e.call(r&&r.proxy):e}}const go={},vo=()=>Object.create(go),bo=t=>Object.getPrototypeOf(t)===go;function Dl(t,e,n,r=!1){const i={},a=vo();t.propsDefaults=Object.create(null),yo(t,e,i,a);for(const o in t.propsOptions[0])o in i||(i[o]=void 0);n?t.props=r?i:Bs(i):t.type.props?t.props=i:t.props=a,t.attrs=a}function $l(t,e,n,r){const{props:i,attrs:a,vnode:{patchFlag:o}}=t,s=H(i),[l]=t.propsOptions;let c=!1;if((r||o>0)&&!(o&16)){if(o&8){const u=t.vnode.dynamicProps;for(let m=0;m<u.length;m++){let v=u[m];if(Wn(t.emitsOptions,v))continue;const _=e[v];if(l)if(z(a,v))_!==a[v]&&(a[v]=_,c=!0);else{const j=It(v);i[j]=kr(l,s,j,_,t,!1)}else _!==a[v]&&(a[v]=_,c=!0)}}}else{yo(t,e,i,a)&&(c=!0);let u;for(const m in s)(!e||!z(e,m)&&((u=ke(m))===m||!z(e,u)))&&(l?n&&(n[m]!==void 0||n[u]!==void 0)&&(i[m]=kr(l,s,m,void 0,t,!0)):delete i[m]);if(a!==s)for(const m in a)(!e||!z(e,m))&&(delete a[m],c=!0)}c&&Lt(t.attrs,"set","")}function yo(t,e,n,r){const[i,a]=t.propsOptions;let o=!1,s;if(e)for(let l in e){if(Re(l))continue;const c=e[l];let u;i&&z(i,u=It(l))?!a||!a.includes(u)?n[u]=c:(s||(s={}))[u]=c:Wn(t.emitsOptions,l)||(!(l in r)||c!==r[l])&&(r[l]=c,o=!0)}if(a){const l=H(n),c=s||V;for(let u=0;u<a.length;u++){const m=a[u];n[m]=kr(i,l,m,c[m],t,!z(c,m))}}return o}function kr(t,e,n,r,i,a){const o=t[n];if(o!=null){const s=z(o,"default");if(s&&r===void 0){const l=o.default;if(o.type!==Function&&!o.skipFactory&&F(l)){const{propsDefaults:c}=i;if(n in c)r=c[n];else{const u=Je(i);r=c[n]=l.call(null,e),u()}}else r=l}o[0]&&(a&&!s?r=!1:o[1]&&(r===""||r===ke(n))&&(r=!0))}return r}function xo(t,e,n=!1){const r=e.propsCache,i=r.get(t);if(i)return i;const a=t.props,o={},s=[];let l=!1;if(!F(t)){const u=m=>{l=!0;const[v,_]=xo(m,e,!0);rt(o,v),_&&s.push(..._)};!n&&e.mixins.length&&e.mixins.forEach(u),t.extends&&u(t.extends),t.mixins&&t.mixins.forEach(u)}if(!a&&!l)return q(t)&&r.set(t,ye),ye;if(M(a))for(let u=0;u<a.length;u++){const m=It(a[u]);Hi(m)&&(o[m]=V)}else if(a)for(const u in a){const m=It(u);if(Hi(m)){const v=a[u],_=o[m]=M(v)||F(v)?{type:v}:rt({},v);if(_){const j=Wi(Boolean,_.type),N=Wi(String,_.type);_[0]=j>-1,_[1]=N<0||j<N,(j>-1||z(_,"default"))&&s.push(m)}}}const c=[o,s];return q(t)&&r.set(t,c),c}function Hi(t){return t[0]!=="$"&&!Re(t)}function Bi(t){return t===null?"null":typeof t=="function"?t.name||"":typeof t=="object"&&t.constructor&&t.constructor.name||""}function Yi(t,e){return Bi(t)===Bi(e)}function Wi(t,e){return M(e)?e.findIndex(n=>Yi(n,t)):F(e)&&Yi(e,t)?0:-1}const wo=t=>t[0]==="_"||t==="$stable",ii=t=>M(t)?t.map(St):[St(t)],zl=(t,e,n)=>{if(e._n)return e;const r=rl((...i)=>ii(e(...i)),n);return r._c=!1,r},_o=(t,e,n)=>{const r=t._ctx;for(const i in t){if(wo(i))continue;const a=t[i];if(F(a))e[i]=zl(i,a,r);else if(a!=null){const o=ii(a);e[i]=()=>o}}},Ao=(t,e)=>{const n=ii(e);t.slots.default=()=>n},Ul=(t,e)=>{const n=t.slots=vo();if(t.vnode.shapeFlag&32){const r=e._;r?(rt(n,e),Fa(n,"_",r,!0)):_o(e,n)}else e&&Ao(t,e)},Hl=(t,e,n)=>{const{vnode:r,slots:i}=t;let a=!0,o=V;if(r.shapeFlag&32){const s=e._;s?n&&s===1?a=!1:(rt(i,e),!n&&s===1&&delete i._):(a=!e.$stable,_o(e,i)),o=e}else e&&(Ao(t,e),o={default:1});if(a)for(const s in i)!wo(s)&&o[s]==null&&delete i[s]};function Er(t,e,n,r,i=!1){if(M(t)){t.forEach((v,_)=>Er(v,e&&(M(e)?e[_]:e),n,r,i));return}if(On(r)&&!i)return;const a=r.shapeFlag&4?Xn(r.component)||r.component.proxy:r.el,o=i?null:a,{i:s,r:l}=t,c=e&&e.r,u=s.refs===V?s.refs={}:s.refs,m=s.setupState;if(c!=null&&c!==l&&(tt(c)?(u[c]=null,z(m,c)&&(m[c]=null)):mt(c)&&(c.value=null)),F(l))Kt(l,s,12,[o,u]);else{const v=tt(l),_=mt(l);if(v||_){const j=()=>{if(t.f){const N=v?z(m,l)?m[l]:u[l]:l.value;i?M(N)&&Br(N,a):M(N)?N.includes(a)||N.push(a):v?(u[l]=[a],z(m,l)&&(m[l]=u[l])):(l.value=[a],t.k&&(u[t.k]=l.value))}else v?(u[l]=o,z(m,l)&&(m[l]=o)):_&&(l.value=o,t.k&&(u[t.k]=o))};o?(j.id=-1,ct(j,n)):j()}}}const ct=dl;function Bl(t){return Yl(t)}function Yl(t,e){const n=ja();n.__VUE__=!0;const{insert:r,remove:i,patchProp:a,createElement:o,createText:s,createComment:l,setText:c,setElementText:u,parentNode:m,nextSibling:v,setScopeId:_=bt,insertStaticContent:j}=t,N=(f,d,h,p=null,g=null,x=null,O=void 0,y=null,w=!!d.dynamicChildren)=>{if(f===d)return;f&&!Ie(f,d)&&(p=an(f),Ot(f,g,x,!0),f=null),d.patchFlag===-2&&(w=!1,d.dynamicChildren=null);const{type:b,ref:S,shapeFlag:T}=d;switch(b){case Kn:B(f,d,h,p);break;case ue:A(f,d,h,p);break;case sr:f==null&&k(d,h,p,O);break;case Mt:en(f,d,h,p,g,x,O,y,w);break;default:T&1?U(f,d,h,p,g,x,O,y,w):T&6?nn(f,d,h,p,g,x,O,y,w):(T&64||T&128)&&b.process(f,d,h,p,g,x,O,y,w,Pe)}S!=null&&g&&Er(S,f&&f.ref,x,d||f,!d)},B=(f,d,h,p)=>{if(f==null)r(d.el=s(d.children),h,p);else{const g=d.el=f.el;d.children!==f.children&&c(g,d.children)}},A=(f,d,h,p)=>{f==null?r(d.el=l(d.children||""),h,p):d.el=f.el},k=(f,d,h,p)=>{[f.el,f.anchor]=j(f.children,d,h,p,f.el,f.anchor)},C=({el:f,anchor:d},h,p)=>{let g;for(;f&&f!==d;)g=v(f),r(f,h,p),f=g;r(d,h,p)},D=({el:f,anchor:d})=>{let h;for(;f&&f!==d;)h=v(f),i(f),f=h;i(d)},U=(f,d,h,p,g,x,O,y,w)=>{d.type==="svg"?O="svg":d.type==="math"&&(O="mathml"),f==null?L(d,h,p,g,x,O,y,w):vt(f,d,g,x,O,y,w)},L=(f,d,h,p,g,x,O,y)=>{let w,b;const{props:S,shapeFlag:T,transition:I,dirs:R}=f;if(w=f.el=o(f.type,x,S&&S.is,S),T&8?u(w,f.children):T&16&&lt(f.children,w,null,p,g,or(f,x),O,y),R&&ne(f,null,p,"created"),Q(w,f,f.scopeId,O,p),S){for(const Y in S)Y!=="value"&&!Re(Y)&&a(w,Y,null,S[Y],x,f.children,p,g,Nt);"value"in S&&a(w,"value",null,S.value,x),(b=S.onVnodeBeforeMount)&&Et(b,p,f)}R&&ne(f,null,p,"beforeMount");const $=Wl(g,I);$&&I.beforeEnter(w),r(w,d,h),((b=S&&S.onVnodeMounted)||$||R)&&ct(()=>{b&&Et(b,p,f),$&&I.enter(w),R&&ne(f,null,p,"mounted")},g)},Q=(f,d,h,p,g)=>{if(h&&_(f,h),p)for(let x=0;x<p.length;x++)_(f,p[x]);if(g){let x=g.subTree;if(d===x){const O=g.vnode;Q(f,O,O.scopeId,O.slotScopeIds,g.parent)}}},lt=(f,d,h,p,g,x,O,y,w=0)=>{for(let b=w;b<f.length;b++){const S=f[b]=y?Yt(f[b]):St(f[b]);N(null,S,d,h,p,g,x,O,y)}},vt=(f,d,h,p,g,x,O)=>{const y=d.el=f.el;let{patchFlag:w,dynamicChildren:b,dirs:S}=d;w|=f.patchFlag&16;const T=f.props||V,I=d.props||V;let R;if(h&&re(h,!1),(R=I.onVnodeBeforeUpdate)&&Et(R,h,d,f),S&&ne(d,f,h,"beforeUpdate"),h&&re(h,!0),b?Tt(f.dynamicChildren,b,y,h,p,or(d,g),x):O||W(f,d,y,null,h,p,or(d,g),x,!1),w>0){if(w&16)Se(y,d,T,I,h,p,g);else if(w&2&&T.class!==I.class&&a(y,"class",null,I.class,g),w&4&&a(y,"style",T.style,I.style,g),w&8){const $=d.dynamicProps;for(let Y=0;Y<$.length;Y++){const X=$[Y],nt=T[X],yt=I[X];(yt!==nt||X==="value")&&a(y,X,nt,yt,g,f.children,h,p,Nt)}}w&1&&f.children!==d.children&&u(y,d.children)}else!O&&b==null&&Se(y,d,T,I,h,p,g);((R=I.onVnodeUpdated)||S)&&ct(()=>{R&&Et(R,h,d,f),S&&ne(d,f,h,"updated")},p)},Tt=(f,d,h,p,g,x,O)=>{for(let y=0;y<d.length;y++){const w=f[y],b=d[y],S=w.el&&(w.type===Mt||!Ie(w,b)||w.shapeFlag&70)?m(w.el):h;N(w,b,S,null,p,g,x,O,!0)}},Se=(f,d,h,p,g,x,O)=>{if(h!==p){if(h!==V)for(const y in h)!Re(y)&&!(y in p)&&a(f,y,h[y],null,O,d.children,g,x,Nt);for(const y in p){if(Re(y))continue;const w=p[y],b=h[y];w!==b&&y!=="value"&&a(f,y,b,w,O,d.children,g,x,Nt)}"value"in p&&a(f,"value",h.value,p.value,O)}},en=(f,d,h,p,g,x,O,y,w)=>{const b=d.el=f?f.el:s(""),S=d.anchor=f?f.anchor:s("");let{patchFlag:T,dynamicChildren:I,slotScopeIds:R}=d;R&&(y=y?y.concat(R):R),f==null?(r(b,h,p),r(S,h,p),lt(d.children||[],h,S,g,x,O,y,w)):T>0&&T&64&&I&&f.dynamicChildren?(Tt(f.dynamicChildren,I,h,g,x,O,y),(d.key!=null||g&&d===g.subTree)&&Oo(f,d,!0)):W(f,d,h,S,g,x,O,y,w)},nn=(f,d,h,p,g,x,O,y,w)=>{d.slotScopeIds=y,f==null?d.shapeFlag&512?g.ctx.activate(d,h,p,O,w):tr(d,h,p,g,x,O,w):yi(f,d,w)},tr=(f,d,h,p,g,x,O)=>{const y=f.component=rf(f,p,g);if(co(f)&&(y.ctx.renderer=Pe),af(y),y.asyncDep){if(g&&g.registerDep(y,ot),!f.el){const w=y.subTree=pt(ue);A(null,w,d,h)}}else ot(y,f,d,h,g,x,O)},yi=(f,d,h)=>{const p=d.component=f.component;if(ol(f,d,h))if(p.asyncDep&&!p.asyncResolved){J(p,d,h);return}else p.next=d,Qs(p.update),p.effect.dirty=!0,p.update();else d.el=f.el,p.vnode=d},ot=(f,d,h,p,g,x,O)=>{const y=()=>{if(f.isMounted){let{next:S,bu:T,u:I,parent:R,vnode:$}=f;{const pe=ko(f);if(pe){S&&(S.el=$.el,J(f,S,O)),pe.asyncDep.then(()=>{f.isUnmounted||y()});return}}let Y=S,X;re(f,!1),S?(S.el=$.el,J(f,S,O)):S=$,T&&wn(T),(X=S.props&&S.props.onVnodeBeforeUpdate)&&Et(X,R,S,$),re(f,!0);const nt=ir(f),yt=f.subTree;f.subTree=nt,N(yt,nt,m(yt.el),an(yt),f,g,x),S.el=nt.el,Y===null&&sl(f,nt.el),I&&ct(I,g),(X=S.props&&S.props.onVnodeUpdated)&&ct(()=>Et(X,R,S,$),g)}else{let S;const{el:T,props:I}=d,{bm:R,m:$,parent:Y}=f,X=On(d);if(re(f,!1),R&&wn(R),!X&&(S=I&&I.onVnodeBeforeMount)&&Et(S,Y,d),re(f,!0),T&&Ai){const nt=()=>{f.subTree=ir(f),Ai(T,f.subTree,f,g,null)};X?d.type.__asyncLoader().then(()=>!f.isUnmounted&&nt()):nt()}else{const nt=f.subTree=ir(f);N(null,nt,h,p,f,g,x),d.el=nt.el}if($&&ct($,g),!X&&(S=I&&I.onVnodeMounted)){const nt=d;ct(()=>Et(S,Y,nt),g)}(d.shapeFlag&256||Y&&On(Y.vnode)&&Y.vnode.shapeFlag&256)&&f.a&&ct(f.a,g),f.isMounted=!0,d=h=p=null}},w=f.effect=new Kr(y,bt,()=>ni(b),f.scope),b=f.update=()=>{w.dirty&&w.run()};b.id=f.uid,re(f,!0),b()},J=(f,d,h)=>{d.component=f;const p=f.vnode.props;f.vnode=d,f.next=null,$l(f,d.props,p,h),Hl(f,d.children,h),Zt(),Li(f),Qt()},W=(f,d,h,p,g,x,O,y,w=!1)=>{const b=f&&f.children,S=f?f.shapeFlag:0,T=d.children,{patchFlag:I,shapeFlag:R}=d;if(I>0){if(I&128){rn(b,T,h,p,g,x,O,y,w);return}else if(I&256){te(b,T,h,p,g,x,O,y,w);return}}R&8?(S&16&&Nt(b,g,x),T!==b&&u(h,T)):S&16?R&16?rn(b,T,h,p,g,x,O,y,w):Nt(b,g,x,!0):(S&8&&u(h,""),R&16&&lt(T,h,p,g,x,O,y,w))},te=(f,d,h,p,g,x,O,y,w)=>{f=f||ye,d=d||ye;const b=f.length,S=d.length,T=Math.min(b,S);let I;for(I=0;I<T;I++){const R=d[I]=w?Yt(d[I]):St(d[I]);N(f[I],R,h,null,g,x,O,y,w)}b>S?Nt(f,g,x,!0,!1,T):lt(d,h,p,g,x,O,y,w,T)},rn=(f,d,h,p,g,x,O,y,w)=>{let b=0;const S=d.length;let T=f.length-1,I=S-1;for(;b<=T&&b<=I;){const R=f[b],$=d[b]=w?Yt(d[b]):St(d[b]);if(Ie(R,$))N(R,$,h,null,g,x,O,y,w);else break;b++}for(;b<=T&&b<=I;){const R=f[T],$=d[I]=w?Yt(d[I]):St(d[I]);if(Ie(R,$))N(R,$,h,null,g,x,O,y,w);else break;T--,I--}if(b>T){if(b<=I){const R=I+1,$=R<S?d[R].el:p;for(;b<=I;)N(null,d[b]=w?Yt(d[b]):St(d[b]),h,$,g,x,O,y,w),b++}}else if(b>I)for(;b<=T;)Ot(f[b],g,x,!0),b++;else{const R=b,$=b,Y=new Map;for(b=$;b<=I;b++){const ht=d[b]=w?Yt(d[b]):St(d[b]);ht.key!=null&&Y.set(ht.key,b)}let X,nt=0;const yt=I-$+1;let pe=!1,Oi=0;const Ce=new Array(yt);for(b=0;b<yt;b++)Ce[b]=0;for(b=R;b<=T;b++){const ht=f[b];if(nt>=yt){Ot(ht,g,x,!0);continue}let kt;if(ht.key!=null)kt=Y.get(ht.key);else for(X=$;X<=I;X++)if(Ce[X-$]===0&&Ie(ht,d[X])){kt=X;break}kt===void 0?Ot(ht,g,x,!0):(Ce[kt-$]=b+1,kt>=Oi?Oi=kt:pe=!0,N(ht,d[kt],h,null,g,x,O,y,w),nt++)}const ki=pe?Vl(Ce):ye;for(X=ki.length-1,b=yt-1;b>=0;b--){const ht=$+b,kt=d[ht],Ei=ht+1<S?d[ht+1].el:p;Ce[b]===0?N(null,kt,h,Ei,g,x,O,y,w):pe&&(X<0||b!==ki[X]?ee(kt,h,Ei,2):X--)}}},ee=(f,d,h,p,g=null)=>{const{el:x,type:O,transition:y,children:w,shapeFlag:b}=f;if(b&6){ee(f.component.subTree,d,h,p);return}if(b&128){f.suspense.move(d,h,p);return}if(b&64){O.move(f,d,h,Pe);return}if(O===Mt){r(x,d,h);for(let T=0;T<w.length;T++)ee(w[T],d,h,p);r(f.anchor,d,h);return}if(O===sr){C(f,d,h);return}if(p!==2&&b&1&&y)if(p===0)y.beforeEnter(x),r(x,d,h),ct(()=>y.enter(x),g);else{const{leave:T,delayLeave:I,afterLeave:R}=y,$=()=>r(x,d,h),Y=()=>{T(x,()=>{$(),R&&R()})};I?I(x,$,Y):Y()}else r(x,d,h)},Ot=(f,d,h,p=!1,g=!1)=>{const{type:x,props:O,ref:y,children:w,dynamicChildren:b,shapeFlag:S,patchFlag:T,dirs:I}=f;if(y!=null&&Er(y,null,h,f,!0),S&256){d.ctx.deactivate(f);return}const R=S&1&&I,$=!On(f);let Y;if($&&(Y=O&&O.onVnodeBeforeUnmount)&&Et(Y,d,f),S&6)fs(f.component,h,p);else{if(S&128){f.suspense.unmount(h,p);return}R&&ne(f,null,d,"beforeUnmount"),S&64?f.type.remove(f,d,h,g,Pe,p):b&&(x!==Mt||T>0&&T&64)?Nt(b,d,h,!1,!0):(x===Mt&&T&384||!g&&S&16)&&Nt(w,d,h),p&&xi(f)}($&&(Y=O&&O.onVnodeUnmounted)||R)&&ct(()=>{Y&&Et(Y,d,f),R&&ne(f,null,d,"unmounted")},h)},xi=f=>{const{type:d,el:h,anchor:p,transition:g}=f;if(d===Mt){ls(h,p);return}if(d===sr){D(f);return}const x=()=>{i(h),g&&!g.persisted&&g.afterLeave&&g.afterLeave()};if(f.shapeFlag&1&&g&&!g.persisted){const{leave:O,delayLeave:y}=g,w=()=>O(h,x);y?y(f.el,x,w):w()}else x()},ls=(f,d)=>{let h;for(;f!==d;)h=v(f),i(f),f=h;i(d)},fs=(f,d,h)=>{const{bum:p,scope:g,update:x,subTree:O,um:y}=f;p&&wn(p),g.stop(),x&&(x.active=!1,Ot(O,f,d,h)),y&&ct(y,d),ct(()=>{f.isUnmounted=!0},d),d&&d.pendingBranch&&!d.isUnmounted&&f.asyncDep&&!f.asyncResolved&&f.suspenseId===d.pendingId&&(d.deps--,d.deps===0&&d.resolve())},Nt=(f,d,h,p=!1,g=!1,x=0)=>{for(let O=x;O<f.length;O++)Ot(f[O],d,h,p,g)},an=f=>f.shapeFlag&6?an(f.component.subTree):f.shapeFlag&128?f.suspense.next():v(f.anchor||f.el);let er=!1;const wi=(f,d,h)=>{f==null?d._vnode&&Ot(d._vnode,null,null,!0):N(d._vnode||null,f,d,null,null,null,h),er||(er=!0,Li(),io(),er=!1),d._vnode=f},Pe={p:N,um:Ot,m:ee,r:xi,mt:tr,mc:lt,pc:W,pbc:Tt,n:an,o:t};let _i,Ai;return{render:wi,hydrate:_i,createApp:Fl(wi,_i)}}function or({type:t,props:e},n){return n==="svg"&&t==="foreignObject"||n==="mathml"&&t==="annotation-xml"&&e&&e.encoding&&e.encoding.includes("html")?void 0:n}function re({effect:t,update:e},n){t.allowRecurse=e.allowRecurse=n}function Wl(t,e){return(!t||t&&!t.pendingBranch)&&e&&!e.persisted}function Oo(t,e,n=!1){const r=t.children,i=e.children;if(M(r)&&M(i))for(let a=0;a<r.length;a++){const o=r[a];let s=i[a];s.shapeFlag&1&&!s.dynamicChildren&&((s.patchFlag<=0||s.patchFlag===32)&&(s=i[a]=Yt(i[a]),s.el=o.el),n||Oo(o,s)),s.type===Kn&&(s.el=o.el)}}function Vl(t){const e=t.slice(),n=[0];let r,i,a,o,s;const l=t.length;for(r=0;r<l;r++){const c=t[r];if(c!==0){if(i=n[n.length-1],t[i]<c){e[r]=i,n.push(r);continue}for(a=0,o=n.length-1;a<o;)s=a+o>>1,t[n[s]]<c?a=s+1:o=s;c<t[n[a]]&&(a>0&&(e[r]=n[a-1]),n[a]=r)}}for(a=n.length,o=n[a-1];a-- >0;)n[a]=o,o=e[o];return n}function ko(t){const e=t.subTree.component;if(e)return e.asyncDep&&!e.asyncResolved?e:ko(e)}const Kl=t=>t.__isTeleport,Mt=Symbol.for("v-fgt"),Kn=Symbol.for("v-txt"),ue=Symbol.for("v-cmt"),sr=Symbol.for("v-stc"),De=[];let wt=null;function Gl(t=!1){De.push(wt=t?null:[])}function Xl(){De.pop(),wt=De[De.length-1]||null}let We=1;function Vi(t){We+=t}function Eo(t){return t.dynamicChildren=We>0?wt||ye:null,Xl(),We>0&&wt&&wt.push(t),t}function Mu(t,e,n,r,i,a){return Eo(Po(t,e,n,r,i,a,!0))}function ql(t,e,n,r,i){return Eo(pt(t,e,n,r,i,!0))}function Sr(t){return t?t.__v_isVNode===!0:!1}function Ie(t,e){return t.type===e.type&&t.key===e.key}const So=({key:t})=>t??null,En=({ref:t,ref_key:e,ref_for:n})=>(typeof t=="number"&&(t=""+t),t!=null?tt(t)||mt(t)||F(t)?{i:ut,r:t,k:e,f:!!n}:t:null);function Po(t,e=null,n=null,r=0,i=null,a=t===Mt?0:1,o=!1,s=!1){const l={__v_isVNode:!0,__v_skip:!0,type:t,props:e,key:e&&So(e),ref:e&&En(e),scopeId:so,slotScopeIds:null,children:n,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetAnchor:null,staticCount:0,shapeFlag:a,patchFlag:r,dynamicProps:i,dynamicChildren:null,appContext:null,ctx:ut};return s?(ai(l,n),a&128&&t.normalize(l)):n&&(l.shapeFlag|=tt(n)?8:16),We>0&&!o&&wt&&(l.patchFlag>0||a&6)&&l.patchFlag!==32&&wt.push(l),l}const pt=Jl;function Jl(t,e=null,n=null,r=0,i=null,a=!1){if((!t||t===fl)&&(t=ue),Sr(t)){const s=Ae(t,e,!0);return n&&ai(s,n),We>0&&!a&&wt&&(s.shapeFlag&6?wt[wt.indexOf(t)]=s:wt.push(s)),s.patchFlag|=-2,s}if(cf(t)&&(t=t.__vccOpts),e){e=Zl(e);let{class:s,style:l}=e;s&&!tt(s)&&(e.class=Vr(s)),q(l)&&(Za(l)&&!M(l)&&(l=rt({},l)),e.style=Wr(l))}const o=tt(t)?1:ul(t)?128:Kl(t)?64:q(t)?4:F(t)?2:0;return Po(t,e,n,r,i,o,a,!0)}function Zl(t){return t?Za(t)||bo(t)?rt({},t):t:null}function Ae(t,e,n=!1,r=!1){const{props:i,ref:a,patchFlag:o,children:s,transition:l}=t,c=e?tf(i||{},e):i,u={__v_isVNode:!0,__v_skip:!0,type:t.type,props:c,key:c&&So(c),ref:e&&e.ref?n&&a?M(a)?a.concat(En(e)):[a,En(e)]:En(e):a,scopeId:t.scopeId,slotScopeIds:t.slotScopeIds,children:s,target:t.target,targetAnchor:t.targetAnchor,staticCount:t.staticCount,shapeFlag:t.shapeFlag,patchFlag:e&&t.type!==Mt?o===-1?16:o|16:o,dynamicProps:t.dynamicProps,dynamicChildren:t.dynamicChildren,appContext:t.appContext,dirs:t.dirs,transition:l,component:t.component,suspense:t.suspense,ssContent:t.ssContent&&Ae(t.ssContent),ssFallback:t.ssFallback&&Ae(t.ssFallback),el:t.el,anchor:t.anchor,ctx:t.ctx,ce:t.ce};return l&&r&&(u.transition=l.clone(u)),u}function Ql(t=" ",e=0){return pt(Kn,null,t,e)}function Ru(t="",e=!1){return e?(Gl(),ql(ue,null,t)):pt(ue,null,t)}function St(t){return t==null||typeof t=="boolean"?pt(ue):M(t)?pt(Mt,null,t.slice()):typeof t=="object"?Yt(t):pt(Kn,null,String(t))}function Yt(t){return t.el===null&&t.patchFlag!==-1||t.memo?t:Ae(t)}function ai(t,e){let n=0;const{shapeFlag:r}=t;if(e==null)e=null;else if(M(e))n=16;else if(typeof e=="object")if(r&65){const i=e.default;i&&(i._c&&(i._d=!1),ai(t,i()),i._c&&(i._d=!0));return}else{n=32;const i=e._;!i&&!bo(e)?e._ctx=ut:i===3&&ut&&(ut.slots._===1?e._=1:(e._=2,t.patchFlag|=1024))}else F(e)?(e={default:e,_ctx:ut},n=32):(e=String(e),r&64?(n=16,e=[Ql(e)]):n=8);t.children=e,t.shapeFlag|=n}function tf(...t){const e={};for(let n=0;n<t.length;n++){const r=t[n];for(const i in r)if(i==="class")e.class!==r.class&&(e.class=Vr([e.class,r.class]));else if(i==="style")e.style=Wr([e.style,r.style]);else if($n(i)){const a=e[i],o=r[i];o&&a!==o&&!(M(a)&&a.includes(o))&&(e[i]=a?[].concat(a,o):o)}else i!==""&&(e[i]=r[i])}return e}function Et(t,e,n,r=null){At(t,e,7,[n,r])}const ef=po();let nf=0;function rf(t,e,n){const r=t.type,i=(e?e.appContext:t.appContext)||ef,a={uid:nf++,vnode:t,type:r,parent:e,appContext:i,root:null,next:null,subTree:null,effect:null,update:null,scope:new ws(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:e?e.provides:Object.create(i.provides),accessCache:null,renderCache:[],components:null,directives:null,propsOptions:xo(r,i),emitsOptions:oo(r,i),emit:null,emitted:null,propsDefaults:V,inheritAttrs:r.inheritAttrs,ctx:V,data:V,props:V,attrs:V,slots:V,refs:V,setupState:V,setupContext:null,attrsProxy:null,slotsProxy:null,suspense:n,suspenseId:n?n.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return a.ctx={_:a},a.root=e?e.root:a,a.emit=nl.bind(null,a),t.ce&&t.ce(a),a}let at=null,Mn,Pr;{const t=ja(),e=(n,r)=>{let i;return(i=t[n])||(i=t[n]=[]),i.push(r),a=>{i.length>1?i.forEach(o=>o(a)):i[0](a)}};Mn=e("__VUE_INSTANCE_SETTERS__",n=>at=n),Pr=e("__VUE_SSR_SETTERS__",n=>Gn=n)}const Je=t=>{const e=at;return Mn(t),t.scope.on(),()=>{t.scope.off(),Mn(e)}},Ki=()=>{at&&at.scope.off(),Mn(null)};function Co(t){return t.vnode.shapeFlag&4}let Gn=!1;function af(t,e=!1){e&&Pr(e);const{props:n,children:r}=t.vnode,i=Co(t);Dl(t,n,i,e),Ul(t,r);const a=i?of(t,e):void 0;return e&&Pr(!1),a}function of(t,e){const n=t.type;t.accessCache=Object.create(null),t.proxy=new Proxy(t.ctx,Cl);const{setup:r}=n;if(r){const i=t.setupContext=r.length>1?lf(t):null,a=Je(t);Zt();const o=Kt(r,t,0,[t.props,i]);if(Qt(),a(),Ma(o)){if(o.then(Ki,Ki),e)return o.then(s=>{Gi(t,s,e)}).catch(s=>{Yn(s,t,0)});t.asyncDep=o}else Gi(t,o,e)}else Io(t,e)}function Gi(t,e,n){F(e)?t.type.__ssrInlineRender?t.ssrRender=e:t.render=e:q(e)&&(t.setupState=eo(e)),Io(t,n)}let Xi;function Io(t,e,n){const r=t.type;if(!t.render){if(!e&&Xi&&!r.render){const i=r.template||ri(t).template;if(i){const{isCustomElement:a,compilerOptions:o}=t.appContext.config,{delimiters:s,compilerOptions:l}=r,c=rt(rt({isCustomElement:a,delimiters:s},o),l);r.render=Xi(i,c)}}t.render=r.render||bt}{const i=Je(t);Zt();try{Il(t)}finally{Qt(),i()}}}const sf={get(t,e){return dt(t,"get",""),t[e]}};function lf(t){const e=n=>{t.exposed=n||{}};return{attrs:new Proxy(t.attrs,sf),slots:t.slots,emit:t.emit,expose:e}}function Xn(t){if(t.exposed)return t.exposeProxy||(t.exposeProxy=new Proxy(eo(Ys(t.exposed)),{get(e,n){if(n in e)return e[n];if(n in Fe)return Fe[n](t)},has(e,n){return n in e||n in Fe}}))}function ff(t,e=!0){return F(t)?t.displayName||t.name:t.name||e&&t.__name}function cf(t){return F(t)&&"__vccOpts"in t}const ie=(t,e)=>Ws(t,e,Gn);function uf(t,e,n){const r=arguments.length;return r===2?q(e)&&!M(e)?Sr(e)?pt(t,null,[e]):pt(t,e):pt(t,null,e):(r>3?n=Array.prototype.slice.call(arguments,2):r===3&&Sr(n)&&(n=[n]),pt(t,e,n))}const df="3.4.27";/**
* @vue/runtime-dom v3.4.27
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/const mf="http://www.w3.org/2000/svg",hf="http://www.w3.org/1998/Math/MathML",Wt=typeof document<"u"?document:null,qi=Wt&&Wt.createElement("template"),pf={insert:(t,e,n)=>{e.insertBefore(t,n||null)},remove:t=>{const e=t.parentNode;e&&e.removeChild(t)},createElement:(t,e,n,r)=>{const i=e==="svg"?Wt.createElementNS(mf,t):e==="mathml"?Wt.createElementNS(hf,t):Wt.createElement(t,n?{is:n}:void 0);return t==="select"&&r&&r.multiple!=null&&i.setAttribute("multiple",r.multiple),i},createText:t=>Wt.createTextNode(t),createComment:t=>Wt.createComment(t),setText:(t,e)=>{t.nodeValue=e},setElementText:(t,e)=>{t.textContent=e},parentNode:t=>t.parentNode,nextSibling:t=>t.nextSibling,querySelector:t=>Wt.querySelector(t),setScopeId(t,e){t.setAttribute(e,"")},insertStaticContent(t,e,n,r,i,a){const o=n?n.previousSibling:e.lastChild;if(i&&(i===a||i.nextSibling))for(;e.insertBefore(i.cloneNode(!0),n),!(i===a||!(i=i.nextSibling)););else{qi.innerHTML=r==="svg"?`<svg>${t}</svg>`:r==="mathml"?`<math>${t}</math>`:t;const s=qi.content;if(r==="svg"||r==="mathml"){const l=s.firstChild;for(;l.firstChild;)s.appendChild(l.firstChild);s.removeChild(l)}e.insertBefore(s,n)}return[o?o.nextSibling:e.firstChild,n?n.previousSibling:e.lastChild]}},gf=Symbol("_vtc");function vf(t,e,n){const r=t[gf];r&&(e=(e?[e,...r]:[...r]).join(" ")),e==null?t.removeAttribute("class"):n?t.setAttribute("class",e):t.className=e}const Rn=Symbol("_vod"),To=Symbol("_vsh"),Lu={beforeMount(t,{value:e},{transition:n}){t[Rn]=t.style.display==="none"?"":t.style.display,n&&e?n.beforeEnter(t):Te(t,e)},mounted(t,{value:e},{transition:n}){n&&e&&n.enter(t)},updated(t,{value:e,oldValue:n},{transition:r}){!e!=!n&&(r?e?(r.beforeEnter(t),Te(t,!0),r.enter(t)):r.leave(t,()=>{Te(t,!1)}):Te(t,e))},beforeUnmount(t,{value:e}){Te(t,e)}};function Te(t,e){t.style.display=e?t[Rn]:"none",t[To]=!e}const bf=Symbol(""),yf=/(^|;)\s*display\s*:/;function xf(t,e,n){const r=t.style,i=tt(n);let a=!1;if(n&&!i){if(e)if(tt(e))for(const o of e.split(";")){const s=o.slice(0,o.indexOf(":")).trim();n[s]==null&&Sn(r,s,"")}else for(const o in e)n[o]==null&&Sn(r,o,"");for(const o in n)o==="display"&&(a=!0),Sn(r,o,n[o])}else if(i){if(e!==n){const o=r[bf];o&&(n+=";"+o),r.cssText=n,a=yf.test(n)}}else e&&t.removeAttribute("style");Rn in t&&(t[Rn]=a?r.display:"",t[To]&&(r.display="none"))}const Ji=/\s*!important$/;function Sn(t,e,n){if(M(n))n.forEach(r=>Sn(t,e,r));else if(n==null&&(n=""),e.startsWith("--"))t.setProperty(e,n);else{const r=wf(t,e);Ji.test(n)?t.setProperty(ke(r),n.replace(Ji,""),"important"):t[r]=n}}const Zi=["Webkit","Moz","ms"],lr={};function wf(t,e){const n=lr[e];if(n)return n;let r=It(e);if(r!=="filter"&&r in t)return lr[e]=r;r=Hn(r);for(let i=0;i<Zi.length;i++){const a=Zi[i]+r;if(a in t)return lr[e]=a}return e}const Qi="http://www.w3.org/1999/xlink";function _f(t,e,n,r,i){if(r&&e.startsWith("xlink:"))n==null?t.removeAttributeNS(Qi,e.slice(6,e.length)):t.setAttributeNS(Qi,e,n);else{const a=xs(e);n==null||a&&!Da(n)?t.removeAttribute(e):t.setAttribute(e,a?"":n)}}function Af(t,e,n,r,i,a,o){if(e==="innerHTML"||e==="textContent"){r&&o(r,i,a),t[e]=n??"";return}const s=t.tagName;if(e==="value"&&s!=="PROGRESS"&&!s.includes("-")){const c=s==="OPTION"?t.getAttribute("value")||"":t.value,u=n??"";(c!==u||!("_value"in t))&&(t.value=u),n==null&&t.removeAttribute(e),t._value=n;return}let l=!1;if(n===""||n==null){const c=typeof t[e];c==="boolean"?n=Da(n):n==null&&c==="string"?(n="",l=!0):c==="number"&&(n=0,l=!0)}try{t[e]=n}catch{}l&&t.removeAttribute(e)}function ge(t,e,n,r){t.addEventListener(e,n,r)}function Of(t,e,n,r){t.removeEventListener(e,n,r)}const ta=Symbol("_vei");function kf(t,e,n,r,i=null){const a=t[ta]||(t[ta]={}),o=a[e];if(r&&o)o.value=r;else{const[s,l]=Ef(e);if(r){const c=a[e]=Cf(r,i);ge(t,s,c,l)}else o&&(Of(t,s,o,l),a[e]=void 0)}}const ea=/(?:Once|Passive|Capture)$/;function Ef(t){let e;if(ea.test(t)){e={};let r;for(;r=t.match(ea);)t=t.slice(0,t.length-r[0].length),e[r[0].toLowerCase()]=!0}return[t[2]===":"?t.slice(3):ke(t.slice(2)),e]}let fr=0;const Sf=Promise.resolve(),Pf=()=>fr||(Sf.then(()=>fr=0),fr=Date.now());function Cf(t,e){const n=r=>{if(!r._vts)r._vts=Date.now();else if(r._vts<=n.attached)return;At(If(r,n.value),e,5,[r])};return n.value=t,n.attached=Pf(),n}function If(t,e){if(M(e)){const n=t.stopImmediatePropagation;return t.stopImmediatePropagation=()=>{n.call(t),t._stopped=!0},e.map(r=>i=>!i._stopped&&r&&r(i))}else return e}const na=t=>t.charCodeAt(0)===111&&t.charCodeAt(1)===110&&t.charCodeAt(2)>96&&t.charCodeAt(2)<123,Tf=(t,e,n,r,i,a,o,s,l)=>{const c=i==="svg";e==="class"?vf(t,r,c):e==="style"?xf(t,n,r):$n(e)?Hr(e)||kf(t,e,n,r,o):(e[0]==="."?(e=e.slice(1),!0):e[0]==="^"?(e=e.slice(1),!1):Nf(t,e,r,c))?Af(t,e,r,a,o,s,l):(e==="true-value"?t._trueValue=r:e==="false-value"&&(t._falseValue=r),_f(t,e,r,c))};function Nf(t,e,n,r){if(r)return!!(e==="innerHTML"||e==="textContent"||e in t&&na(e)&&F(n));if(e==="spellcheck"||e==="draggable"||e==="translate"||e==="form"||e==="list"&&t.tagName==="INPUT"||e==="type"&&t.tagName==="TEXTAREA")return!1;if(e==="width"||e==="height"){const i=t.tagName;if(i==="IMG"||i==="VIDEO"||i==="CANVAS"||i==="SOURCE")return!1}return na(e)&&tt(n)?!1:e in t}const ra=t=>{const e=t.props["onUpdate:modelValue"]||!1;return M(e)?n=>wn(e,n):e};function Mf(t){t.target.composing=!0}function ia(t){const e=t.target;e.composing&&(e.composing=!1,e.dispatchEvent(new Event("input")))}const cr=Symbol("_assign"),Fu={created(t,{modifiers:{lazy:e,trim:n,number:r}},i){t[cr]=ra(i);const a=r||i.props&&i.props.type==="number";ge(t,e?"change":"input",o=>{if(o.target.composing)return;let s=t.value;n&&(s=s.trim()),a&&(s=gr(s)),t[cr](s)}),n&&ge(t,"change",()=>{t.value=t.value.trim()}),e||(ge(t,"compositionstart",Mf),ge(t,"compositionend",ia),ge(t,"change",ia))},mounted(t,{value:e}){t.value=e??""},beforeUpdate(t,{value:e,modifiers:{lazy:n,trim:r,number:i}},a){if(t[cr]=ra(a),t.composing)return;const o=(i||t.type==="number")&&!/^0\d/.test(t.value)?gr(t.value):t.value,s=e??"";o!==s&&(document.activeElement===t&&t.type!=="range"&&(n||r&&t.value.trim()===s)||(t.value=s))}},Rf=rt({patchProp:Tf},pf);let aa;function Lf(){return aa||(aa=Bl(Rf))}const ju=(...t)=>{const e=Lf().createApp(...t),{mount:n}=e;return e.mount=r=>{const i=jf(r);if(!i)return;const a=e._component;!F(a)&&!a.render&&!a.template&&(a.template=i.innerHTML),i.innerHTML="";const o=n(i,!1,Ff(i));return i instanceof Element&&(i.removeAttribute("v-cloak"),i.setAttribute("data-v-app","")),o},e};function Ff(t){if(t instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&t instanceof MathMLElement)return"mathml"}function jf(t){return tt(t)?document.querySelector(t):t}function oa(t,e){var n=Object.keys(t);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(t);e&&(r=r.filter(function(i){return Object.getOwnPropertyDescriptor(t,i).enumerable})),n.push.apply(n,r)}return n}function E(t){for(var e=1;e<arguments.length;e++){var n=arguments[e]!=null?arguments[e]:{};e%2?oa(Object(n),!0).forEach(function(r){et(t,r,n[r])}):Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(n)):oa(Object(n)).forEach(function(r){Object.defineProperty(t,r,Object.getOwnPropertyDescriptor(n,r))})}return t}function Ln(t){"@babel/helpers - typeof";return Ln=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(e){return typeof e}:function(e){return e&&typeof Symbol=="function"&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},Ln(t)}function Df(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}function $f(t,e){for(var n=0;n<e.length;n++){var r=e[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(t,r.key,r)}}function zf(t,e,n){return e&&$f(t.prototype,e),Object.defineProperty(t,"prototype",{writable:!1}),t}function et(t,e,n){return e in t?Object.defineProperty(t,e,{value:n,enumerable:!0,configurable:!0,writable:!0}):t[e]=n,t}function oi(t,e){return Hf(t)||Yf(t,e)||No(t,e)||Vf()}function Ze(t){return Uf(t)||Bf(t)||No(t)||Wf()}function Uf(t){if(Array.isArray(t))return Cr(t)}function Hf(t){if(Array.isArray(t))return t}function Bf(t){if(typeof Symbol<"u"&&t[Symbol.iterator]!=null||t["@@iterator"]!=null)return Array.from(t)}function Yf(t,e){var n=t==null?null:typeof Symbol<"u"&&t[Symbol.iterator]||t["@@iterator"];if(n!=null){var r=[],i=!0,a=!1,o,s;try{for(n=n.call(t);!(i=(o=n.next()).done)&&(r.push(o.value),!(e&&r.length===e));i=!0);}catch(l){a=!0,s=l}finally{try{!i&&n.return!=null&&n.return()}finally{if(a)throw s}}return r}}function No(t,e){if(t){if(typeof t=="string")return Cr(t,e);var n=Object.prototype.toString.call(t).slice(8,-1);if(n==="Object"&&t.constructor&&(n=t.constructor.name),n==="Map"||n==="Set")return Array.from(t);if(n==="Arguments"||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return Cr(t,e)}}function Cr(t,e){(e==null||e>t.length)&&(e=t.length);for(var n=0,r=new Array(e);n<e;n++)r[n]=t[n];return r}function Wf(){throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}function Vf(){throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}var sa=function(){},si={},Mo={},Ro=null,Lo={mark:sa,measure:sa};try{typeof window<"u"&&(si=window),typeof document<"u"&&(Mo=document),typeof MutationObserver<"u"&&(Ro=MutationObserver),typeof performance<"u"&&(Lo=performance)}catch{}var Kf=si.navigator||{},la=Kf.userAgent,fa=la===void 0?"":la,Xt=si,G=Mo,ca=Ro,dn=Lo;Xt.document;var zt=!!G.documentElement&&!!G.head&&typeof G.addEventListener=="function"&&typeof G.createElement=="function",Fo=~fa.indexOf("MSIE")||~fa.indexOf("Trident/"),mn,hn,pn,gn,vn,Ft="___FONT_AWESOME___",Ir=16,jo="fa",Do="svg-inline--fa",de="data-fa-i2svg",Tr="data-fa-pseudo-element",Gf="data-fa-pseudo-element-pending",li="data-prefix",fi="data-icon",ua="fontawesome-i2svg",Xf="async",qf=["HTML","HEAD","STYLE","SCRIPT"],$o=function(){try{return!0}catch{return!1}}(),K="classic",Z="sharp",ci=[K,Z];function Qe(t){return new Proxy(t,{get:function(n,r){return r in n?n[r]:n[K]}})}var Ve=Qe((mn={},et(mn,K,{fa:"solid",fas:"solid","fa-solid":"solid",far:"regular","fa-regular":"regular",fal:"light","fa-light":"light",fat:"thin","fa-thin":"thin",fad:"duotone","fa-duotone":"duotone",fab:"brands","fa-brands":"brands",fak:"kit",fakd:"kit","fa-kit":"kit","fa-kit-duotone":"kit"}),et(mn,Z,{fa:"solid",fass:"solid","fa-solid":"solid",fasr:"regular","fa-regular":"regular",fasl:"light","fa-light":"light",fast:"thin","fa-thin":"thin"}),mn)),Ke=Qe((hn={},et(hn,K,{solid:"fas",regular:"far",light:"fal",thin:"fat",duotone:"fad",brands:"fab",kit:"fak"}),et(hn,Z,{solid:"fass",regular:"fasr",light:"fasl",thin:"fast"}),hn)),Ge=Qe((pn={},et(pn,K,{fab:"fa-brands",fad:"fa-duotone",fak:"fa-kit",fal:"fa-light",far:"fa-regular",fas:"fa-solid",fat:"fa-thin"}),et(pn,Z,{fass:"fa-solid",fasr:"fa-regular",fasl:"fa-light",fast:"fa-thin"}),pn)),Jf=Qe((gn={},et(gn,K,{"fa-brands":"fab","fa-duotone":"fad","fa-kit":"fak","fa-light":"fal","fa-regular":"far","fa-solid":"fas","fa-thin":"fat"}),et(gn,Z,{"fa-solid":"fass","fa-regular":"fasr","fa-light":"fasl","fa-thin":"fast"}),gn)),Zf=/fa(s|r|l|t|d|b|k|ss|sr|sl|st)?[\-\ ]/,zo="fa-layers-text",Qf=/Font ?Awesome ?([56 ]*)(Solid|Regular|Light|Thin|Duotone|Brands|Free|Pro|Sharp|Kit)?.*/i,tc=Qe((vn={},et(vn,K,{900:"fas",400:"far",normal:"far",300:"fal",100:"fat"}),et(vn,Z,{900:"fass",400:"fasr",300:"fasl",100:"fast"}),vn)),Uo=[1,2,3,4,5,6,7,8,9,10],ec=Uo.concat([11,12,13,14,15,16,17,18,19,20]),nc=["class","data-prefix","data-icon","data-fa-transform","data-fa-mask"],se={GROUP:"duotone-group",SWAP_OPACITY:"swap-opacity",PRIMARY:"primary",SECONDARY:"secondary"},Xe=new Set;Object.keys(Ke[K]).map(Xe.add.bind(Xe));Object.keys(Ke[Z]).map(Xe.add.bind(Xe));var rc=[].concat(ci,Ze(Xe),["2xs","xs","sm","lg","xl","2xl","beat","border","fade","beat-fade","bounce","flip-both","flip-horizontal","flip-vertical","flip","fw","inverse","layers-counter","layers-text","layers","li","pull-left","pull-right","pulse","rotate-180","rotate-270","rotate-90","rotate-by","shake","spin-pulse","spin-reverse","spin","stack-1x","stack-2x","stack","ul",se.GROUP,se.SWAP_OPACITY,se.PRIMARY,se.SECONDARY]).concat(Uo.map(function(t){return"".concat(t,"x")})).concat(ec.map(function(t){return"w-".concat(t)})),$e=Xt.FontAwesomeConfig||{};function ic(t){var e=G.querySelector("script["+t+"]");if(e)return e.getAttribute(t)}function ac(t){return t===""?!0:t==="false"?!1:t==="true"?!0:t}if(G&&typeof G.querySelector=="function"){var oc=[["data-family-prefix","familyPrefix"],["data-css-prefix","cssPrefix"],["data-family-default","familyDefault"],["data-style-default","styleDefault"],["data-replacement-class","replacementClass"],["data-auto-replace-svg","autoReplaceSvg"],["data-auto-add-css","autoAddCss"],["data-auto-a11y","autoA11y"],["data-search-pseudo-elements","searchPseudoElements"],["data-observe-mutations","observeMutations"],["data-mutate-approach","mutateApproach"],["data-keep-original-source","keepOriginalSource"],["data-measure-performance","measurePerformance"],["data-show-missing-icons","showMissingIcons"]];oc.forEach(function(t){var e=oi(t,2),n=e[0],r=e[1],i=ac(ic(n));i!=null&&($e[r]=i)})}var Ho={styleDefault:"solid",familyDefault:"classic",cssPrefix:jo,replacementClass:Do,autoReplaceSvg:!0,autoAddCss:!0,autoA11y:!0,searchPseudoElements:!1,observeMutations:!0,mutateApproach:"async",keepOriginalSource:!0,measurePerformance:!1,showMissingIcons:!0};$e.familyPrefix&&($e.cssPrefix=$e.familyPrefix);var Oe=E(E({},Ho),$e);Oe.autoReplaceSvg||(Oe.observeMutations=!1);var P={};Object.keys(Ho).forEach(function(t){Object.defineProperty(P,t,{enumerable:!0,set:function(n){Oe[t]=n,ze.forEach(function(r){return r(P)})},get:function(){return Oe[t]}})});Object.defineProperty(P,"familyPrefix",{enumerable:!0,set:function(e){Oe.cssPrefix=e,ze.forEach(function(n){return n(P)})},get:function(){return Oe.cssPrefix}});Xt.FontAwesomeConfig=P;var ze=[];function sc(t){return ze.push(t),function(){ze.splice(ze.indexOf(t),1)}}var Ht=Ir,Ct={size:16,x:0,y:0,rotate:0,flipX:!1,flipY:!1};function lc(t){if(!(!t||!zt)){var e=G.createElement("style");e.setAttribute("type","text/css"),e.innerHTML=t;for(var n=G.head.childNodes,r=null,i=n.length-1;i>-1;i--){var a=n[i],o=(a.tagName||"").toUpperCase();["STYLE","LINK"].indexOf(o)>-1&&(r=a)}return G.head.insertBefore(e,r),t}}var fc="0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";function qe(){for(var t=12,e="";t-- >0;)e+=fc[Math.random()*62|0];return e}function Ee(t){for(var e=[],n=(t||[]).length>>>0;n--;)e[n]=t[n];return e}function ui(t){return t.classList?Ee(t.classList):(t.getAttribute("class")||"").split(" ").filter(function(e){return e})}function Bo(t){return"".concat(t).replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/'/g,"&#39;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function cc(t){return Object.keys(t||{}).reduce(function(e,n){return e+"".concat(n,'="').concat(Bo(t[n]),'" ')},"").trim()}function qn(t){return Object.keys(t||{}).reduce(function(e,n){return e+"".concat(n,": ").concat(t[n].trim(),";")},"")}function di(t){return t.size!==Ct.size||t.x!==Ct.x||t.y!==Ct.y||t.rotate!==Ct.rotate||t.flipX||t.flipY}function uc(t){var e=t.transform,n=t.containerWidth,r=t.iconWidth,i={transform:"translate(".concat(n/2," 256)")},a="translate(".concat(e.x*32,", ").concat(e.y*32,") "),o="scale(".concat(e.size/16*(e.flipX?-1:1),", ").concat(e.size/16*(e.flipY?-1:1),") "),s="rotate(".concat(e.rotate," 0 0)"),l={transform:"".concat(a," ").concat(o," ").concat(s)},c={transform:"translate(".concat(r/2*-1," -256)")};return{outer:i,inner:l,path:c}}function dc(t){var e=t.transform,n=t.width,r=n===void 0?Ir:n,i=t.height,a=i===void 0?Ir:i,o=t.startCentered,s=o===void 0?!1:o,l="";return s&&Fo?l+="translate(".concat(e.x/Ht-r/2,"em, ").concat(e.y/Ht-a/2,"em) "):s?l+="translate(calc(-50% + ".concat(e.x/Ht,"em), calc(-50% + ").concat(e.y/Ht,"em)) "):l+="translate(".concat(e.x/Ht,"em, ").concat(e.y/Ht,"em) "),l+="scale(".concat(e.size/Ht*(e.flipX?-1:1),", ").concat(e.size/Ht*(e.flipY?-1:1),") "),l+="rotate(".concat(e.rotate,"deg) "),l}var mc=`:root, :host {
  --fa-font-solid: normal 900 1em/1 "Font Awesome 6 Solid";
  --fa-font-regular: normal 400 1em/1 "Font Awesome 6 Regular";
  --fa-font-light: normal 300 1em/1 "Font Awesome 6 Light";
  --fa-font-thin: normal 100 1em/1 "Font Awesome 6 Thin";
  --fa-font-duotone: normal 900 1em/1 "Font Awesome 6 Duotone";
  --fa-font-sharp-solid: normal 900 1em/1 "Font Awesome 6 Sharp";
  --fa-font-sharp-regular: normal 400 1em/1 "Font Awesome 6 Sharp";
  --fa-font-sharp-light: normal 300 1em/1 "Font Awesome 6 Sharp";
  --fa-font-sharp-thin: normal 100 1em/1 "Font Awesome 6 Sharp";
  --fa-font-brands: normal 400 1em/1 "Font Awesome 6 Brands";
}

svg:not(:root).svg-inline--fa, svg:not(:host).svg-inline--fa {
  overflow: visible;
  box-sizing: content-box;
}

.svg-inline--fa {
  display: var(--fa-display, inline-block);
  height: 1em;
  overflow: visible;
  vertical-align: -0.125em;
}
.svg-inline--fa.fa-2xs {
  vertical-align: 0.1em;
}
.svg-inline--fa.fa-xs {
  vertical-align: 0em;
}
.svg-inline--fa.fa-sm {
  vertical-align: -0.0714285705em;
}
.svg-inline--fa.fa-lg {
  vertical-align: -0.2em;
}
.svg-inline--fa.fa-xl {
  vertical-align: -0.25em;
}
.svg-inline--fa.fa-2xl {
  vertical-align: -0.3125em;
}
.svg-inline--fa.fa-pull-left {
  margin-right: var(--fa-pull-margin, 0.3em);
  width: auto;
}
.svg-inline--fa.fa-pull-right {
  margin-left: var(--fa-pull-margin, 0.3em);
  width: auto;
}
.svg-inline--fa.fa-li {
  width: var(--fa-li-width, 2em);
  top: 0.25em;
}
.svg-inline--fa.fa-fw {
  width: var(--fa-fw-width, 1.25em);
}

.fa-layers svg.svg-inline--fa {
  bottom: 0;
  left: 0;
  margin: auto;
  position: absolute;
  right: 0;
  top: 0;
}

.fa-layers-counter, .fa-layers-text {
  display: inline-block;
  position: absolute;
  text-align: center;
}

.fa-layers {
  display: inline-block;
  height: 1em;
  position: relative;
  text-align: center;
  vertical-align: -0.125em;
  width: 1em;
}
.fa-layers svg.svg-inline--fa {
  -webkit-transform-origin: center center;
          transform-origin: center center;
}

.fa-layers-text {
  left: 50%;
  top: 50%;
  -webkit-transform: translate(-50%, -50%);
          transform: translate(-50%, -50%);
  -webkit-transform-origin: center center;
          transform-origin: center center;
}

.fa-layers-counter {
  background-color: var(--fa-counter-background-color, #ff253a);
  border-radius: var(--fa-counter-border-radius, 1em);
  box-sizing: border-box;
  color: var(--fa-inverse, #fff);
  line-height: var(--fa-counter-line-height, 1);
  max-width: var(--fa-counter-max-width, 5em);
  min-width: var(--fa-counter-min-width, 1.5em);
  overflow: hidden;
  padding: var(--fa-counter-padding, 0.25em 0.5em);
  right: var(--fa-right, 0);
  text-overflow: ellipsis;
  top: var(--fa-top, 0);
  -webkit-transform: scale(var(--fa-counter-scale, 0.25));
          transform: scale(var(--fa-counter-scale, 0.25));
  -webkit-transform-origin: top right;
          transform-origin: top right;
}

.fa-layers-bottom-right {
  bottom: var(--fa-bottom, 0);
  right: var(--fa-right, 0);
  top: auto;
  -webkit-transform: scale(var(--fa-layers-scale, 0.25));
          transform: scale(var(--fa-layers-scale, 0.25));
  -webkit-transform-origin: bottom right;
          transform-origin: bottom right;
}

.fa-layers-bottom-left {
  bottom: var(--fa-bottom, 0);
  left: var(--fa-left, 0);
  right: auto;
  top: auto;
  -webkit-transform: scale(var(--fa-layers-scale, 0.25));
          transform: scale(var(--fa-layers-scale, 0.25));
  -webkit-transform-origin: bottom left;
          transform-origin: bottom left;
}

.fa-layers-top-right {
  top: var(--fa-top, 0);
  right: var(--fa-right, 0);
  -webkit-transform: scale(var(--fa-layers-scale, 0.25));
          transform: scale(var(--fa-layers-scale, 0.25));
  -webkit-transform-origin: top right;
          transform-origin: top right;
}

.fa-layers-top-left {
  left: var(--fa-left, 0);
  right: auto;
  top: var(--fa-top, 0);
  -webkit-transform: scale(var(--fa-layers-scale, 0.25));
          transform: scale(var(--fa-layers-scale, 0.25));
  -webkit-transform-origin: top left;
          transform-origin: top left;
}

.fa-1x {
  font-size: 1em;
}

.fa-2x {
  font-size: 2em;
}

.fa-3x {
  font-size: 3em;
}

.fa-4x {
  font-size: 4em;
}

.fa-5x {
  font-size: 5em;
}

.fa-6x {
  font-size: 6em;
}

.fa-7x {
  font-size: 7em;
}

.fa-8x {
  font-size: 8em;
}

.fa-9x {
  font-size: 9em;
}

.fa-10x {
  font-size: 10em;
}

.fa-2xs {
  font-size: 0.625em;
  line-height: 0.1em;
  vertical-align: 0.225em;
}

.fa-xs {
  font-size: 0.75em;
  line-height: 0.0833333337em;
  vertical-align: 0.125em;
}

.fa-sm {
  font-size: 0.875em;
  line-height: 0.0714285718em;
  vertical-align: 0.0535714295em;
}

.fa-lg {
  font-size: 1.25em;
  line-height: 0.05em;
  vertical-align: -0.075em;
}

.fa-xl {
  font-size: 1.5em;
  line-height: 0.0416666682em;
  vertical-align: -0.125em;
}

.fa-2xl {
  font-size: 2em;
  line-height: 0.03125em;
  vertical-align: -0.1875em;
}

.fa-fw {
  text-align: center;
  width: 1.25em;
}

.fa-ul {
  list-style-type: none;
  margin-left: var(--fa-li-margin, 2.5em);
  padding-left: 0;
}
.fa-ul > li {
  position: relative;
}

.fa-li {
  left: calc(var(--fa-li-width, 2em) * -1);
  position: absolute;
  text-align: center;
  width: var(--fa-li-width, 2em);
  line-height: inherit;
}

.fa-border {
  border-color: var(--fa-border-color, #eee);
  border-radius: var(--fa-border-radius, 0.1em);
  border-style: var(--fa-border-style, solid);
  border-width: var(--fa-border-width, 0.08em);
  padding: var(--fa-border-padding, 0.2em 0.25em 0.15em);
}

.fa-pull-left {
  float: left;
  margin-right: var(--fa-pull-margin, 0.3em);
}

.fa-pull-right {
  float: right;
  margin-left: var(--fa-pull-margin, 0.3em);
}

.fa-beat {
  -webkit-animation-name: fa-beat;
          animation-name: fa-beat;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, ease-in-out);
          animation-timing-function: var(--fa-animation-timing, ease-in-out);
}

.fa-bounce {
  -webkit-animation-name: fa-bounce;
          animation-name: fa-bounce;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.28, 0.84, 0.42, 1));
          animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.28, 0.84, 0.42, 1));
}

.fa-fade {
  -webkit-animation-name: fa-fade;
          animation-name: fa-fade;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));
          animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));
}

.fa-beat-fade {
  -webkit-animation-name: fa-beat-fade;
          animation-name: fa-beat-fade;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));
          animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));
}

.fa-flip {
  -webkit-animation-name: fa-flip;
          animation-name: fa-flip;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, ease-in-out);
          animation-timing-function: var(--fa-animation-timing, ease-in-out);
}

.fa-shake {
  -webkit-animation-name: fa-shake;
          animation-name: fa-shake;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, linear);
          animation-timing-function: var(--fa-animation-timing, linear);
}

.fa-spin {
  -webkit-animation-name: fa-spin;
          animation-name: fa-spin;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 2s);
          animation-duration: var(--fa-animation-duration, 2s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, linear);
          animation-timing-function: var(--fa-animation-timing, linear);
}

.fa-spin-reverse {
  --fa-animation-direction: reverse;
}

.fa-pulse,
.fa-spin-pulse {
  -webkit-animation-name: fa-spin;
          animation-name: fa-spin;
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, steps(8));
          animation-timing-function: var(--fa-animation-timing, steps(8));
}

@media (prefers-reduced-motion: reduce) {
  .fa-beat,
.fa-bounce,
.fa-fade,
.fa-beat-fade,
.fa-flip,
.fa-pulse,
.fa-shake,
.fa-spin,
.fa-spin-pulse {
    -webkit-animation-delay: -1ms;
            animation-delay: -1ms;
    -webkit-animation-duration: 1ms;
            animation-duration: 1ms;
    -webkit-animation-iteration-count: 1;
            animation-iteration-count: 1;
    -webkit-transition-delay: 0s;
            transition-delay: 0s;
    -webkit-transition-duration: 0s;
            transition-duration: 0s;
  }
}
@-webkit-keyframes fa-beat {
  0%, 90% {
    -webkit-transform: scale(1);
            transform: scale(1);
  }
  45% {
    -webkit-transform: scale(var(--fa-beat-scale, 1.25));
            transform: scale(var(--fa-beat-scale, 1.25));
  }
}
@keyframes fa-beat {
  0%, 90% {
    -webkit-transform: scale(1);
            transform: scale(1);
  }
  45% {
    -webkit-transform: scale(var(--fa-beat-scale, 1.25));
            transform: scale(var(--fa-beat-scale, 1.25));
  }
}
@-webkit-keyframes fa-bounce {
  0% {
    -webkit-transform: scale(1, 1) translateY(0);
            transform: scale(1, 1) translateY(0);
  }
  10% {
    -webkit-transform: scale(var(--fa-bounce-start-scale-x, 1.1), var(--fa-bounce-start-scale-y, 0.9)) translateY(0);
            transform: scale(var(--fa-bounce-start-scale-x, 1.1), var(--fa-bounce-start-scale-y, 0.9)) translateY(0);
  }
  30% {
    -webkit-transform: scale(var(--fa-bounce-jump-scale-x, 0.9), var(--fa-bounce-jump-scale-y, 1.1)) translateY(var(--fa-bounce-height, -0.5em));
            transform: scale(var(--fa-bounce-jump-scale-x, 0.9), var(--fa-bounce-jump-scale-y, 1.1)) translateY(var(--fa-bounce-height, -0.5em));
  }
  50% {
    -webkit-transform: scale(var(--fa-bounce-land-scale-x, 1.05), var(--fa-bounce-land-scale-y, 0.95)) translateY(0);
            transform: scale(var(--fa-bounce-land-scale-x, 1.05), var(--fa-bounce-land-scale-y, 0.95)) translateY(0);
  }
  57% {
    -webkit-transform: scale(1, 1) translateY(var(--fa-bounce-rebound, -0.125em));
            transform: scale(1, 1) translateY(var(--fa-bounce-rebound, -0.125em));
  }
  64% {
    -webkit-transform: scale(1, 1) translateY(0);
            transform: scale(1, 1) translateY(0);
  }
  100% {
    -webkit-transform: scale(1, 1) translateY(0);
            transform: scale(1, 1) translateY(0);
  }
}
@keyframes fa-bounce {
  0% {
    -webkit-transform: scale(1, 1) translateY(0);
            transform: scale(1, 1) translateY(0);
  }
  10% {
    -webkit-transform: scale(var(--fa-bounce-start-scale-x, 1.1), var(--fa-bounce-start-scale-y, 0.9)) translateY(0);
            transform: scale(var(--fa-bounce-start-scale-x, 1.1), var(--fa-bounce-start-scale-y, 0.9)) translateY(0);
  }
  30% {
    -webkit-transform: scale(var(--fa-bounce-jump-scale-x, 0.9), var(--fa-bounce-jump-scale-y, 1.1)) translateY(var(--fa-bounce-height, -0.5em));
            transform: scale(var(--fa-bounce-jump-scale-x, 0.9), var(--fa-bounce-jump-scale-y, 1.1)) translateY(var(--fa-bounce-height, -0.5em));
  }
  50% {
    -webkit-transform: scale(var(--fa-bounce-land-scale-x, 1.05), var(--fa-bounce-land-scale-y, 0.95)) translateY(0);
            transform: scale(var(--fa-bounce-land-scale-x, 1.05), var(--fa-bounce-land-scale-y, 0.95)) translateY(0);
  }
  57% {
    -webkit-transform: scale(1, 1) translateY(var(--fa-bounce-rebound, -0.125em));
            transform: scale(1, 1) translateY(var(--fa-bounce-rebound, -0.125em));
  }
  64% {
    -webkit-transform: scale(1, 1) translateY(0);
            transform: scale(1, 1) translateY(0);
  }
  100% {
    -webkit-transform: scale(1, 1) translateY(0);
            transform: scale(1, 1) translateY(0);
  }
}
@-webkit-keyframes fa-fade {
  50% {
    opacity: var(--fa-fade-opacity, 0.4);
  }
}
@keyframes fa-fade {
  50% {
    opacity: var(--fa-fade-opacity, 0.4);
  }
}
@-webkit-keyframes fa-beat-fade {
  0%, 100% {
    opacity: var(--fa-beat-fade-opacity, 0.4);
    -webkit-transform: scale(1);
            transform: scale(1);
  }
  50% {
    opacity: 1;
    -webkit-transform: scale(var(--fa-beat-fade-scale, 1.125));
            transform: scale(var(--fa-beat-fade-scale, 1.125));
  }
}
@keyframes fa-beat-fade {
  0%, 100% {
    opacity: var(--fa-beat-fade-opacity, 0.4);
    -webkit-transform: scale(1);
            transform: scale(1);
  }
  50% {
    opacity: 1;
    -webkit-transform: scale(var(--fa-beat-fade-scale, 1.125));
            transform: scale(var(--fa-beat-fade-scale, 1.125));
  }
}
@-webkit-keyframes fa-flip {
  50% {
    -webkit-transform: rotate3d(var(--fa-flip-x, 0), var(--fa-flip-y, 1), var(--fa-flip-z, 0), var(--fa-flip-angle, -180deg));
            transform: rotate3d(var(--fa-flip-x, 0), var(--fa-flip-y, 1), var(--fa-flip-z, 0), var(--fa-flip-angle, -180deg));
  }
}
@keyframes fa-flip {
  50% {
    -webkit-transform: rotate3d(var(--fa-flip-x, 0), var(--fa-flip-y, 1), var(--fa-flip-z, 0), var(--fa-flip-angle, -180deg));
            transform: rotate3d(var(--fa-flip-x, 0), var(--fa-flip-y, 1), var(--fa-flip-z, 0), var(--fa-flip-angle, -180deg));
  }
}
@-webkit-keyframes fa-shake {
  0% {
    -webkit-transform: rotate(-15deg);
            transform: rotate(-15deg);
  }
  4% {
    -webkit-transform: rotate(15deg);
            transform: rotate(15deg);
  }
  8%, 24% {
    -webkit-transform: rotate(-18deg);
            transform: rotate(-18deg);
  }
  12%, 28% {
    -webkit-transform: rotate(18deg);
            transform: rotate(18deg);
  }
  16% {
    -webkit-transform: rotate(-22deg);
            transform: rotate(-22deg);
  }
  20% {
    -webkit-transform: rotate(22deg);
            transform: rotate(22deg);
  }
  32% {
    -webkit-transform: rotate(-12deg);
            transform: rotate(-12deg);
  }
  36% {
    -webkit-transform: rotate(12deg);
            transform: rotate(12deg);
  }
  40%, 100% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }
}
@keyframes fa-shake {
  0% {
    -webkit-transform: rotate(-15deg);
            transform: rotate(-15deg);
  }
  4% {
    -webkit-transform: rotate(15deg);
            transform: rotate(15deg);
  }
  8%, 24% {
    -webkit-transform: rotate(-18deg);
            transform: rotate(-18deg);
  }
  12%, 28% {
    -webkit-transform: rotate(18deg);
            transform: rotate(18deg);
  }
  16% {
    -webkit-transform: rotate(-22deg);
            transform: rotate(-22deg);
  }
  20% {
    -webkit-transform: rotate(22deg);
            transform: rotate(22deg);
  }
  32% {
    -webkit-transform: rotate(-12deg);
            transform: rotate(-12deg);
  }
  36% {
    -webkit-transform: rotate(12deg);
            transform: rotate(12deg);
  }
  40%, 100% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }
}
@-webkit-keyframes fa-spin {
  0% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg);
  }
}
@keyframes fa-spin {
  0% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg);
  }
}
.fa-rotate-90 {
  -webkit-transform: rotate(90deg);
          transform: rotate(90deg);
}

.fa-rotate-180 {
  -webkit-transform: rotate(180deg);
          transform: rotate(180deg);
}

.fa-rotate-270 {
  -webkit-transform: rotate(270deg);
          transform: rotate(270deg);
}

.fa-flip-horizontal {
  -webkit-transform: scale(-1, 1);
          transform: scale(-1, 1);
}

.fa-flip-vertical {
  -webkit-transform: scale(1, -1);
          transform: scale(1, -1);
}

.fa-flip-both,
.fa-flip-horizontal.fa-flip-vertical {
  -webkit-transform: scale(-1, -1);
          transform: scale(-1, -1);
}

.fa-rotate-by {
  -webkit-transform: rotate(var(--fa-rotate-angle, 0));
          transform: rotate(var(--fa-rotate-angle, 0));
}

.fa-stack {
  display: inline-block;
  vertical-align: middle;
  height: 2em;
  position: relative;
  width: 2.5em;
}

.fa-stack-1x,
.fa-stack-2x {
  bottom: 0;
  left: 0;
  margin: auto;
  position: absolute;
  right: 0;
  top: 0;
  z-index: var(--fa-stack-z-index, auto);
}

.svg-inline--fa.fa-stack-1x {
  height: 1em;
  width: 1.25em;
}
.svg-inline--fa.fa-stack-2x {
  height: 2em;
  width: 2.5em;
}

.fa-inverse {
  color: var(--fa-inverse, #fff);
}

.sr-only,
.fa-sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}

.sr-only-focusable:not(:focus),
.fa-sr-only-focusable:not(:focus) {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}

.svg-inline--fa .fa-primary {
  fill: var(--fa-primary-color, currentColor);
  opacity: var(--fa-primary-opacity, 1);
}

.svg-inline--fa .fa-secondary {
  fill: var(--fa-secondary-color, currentColor);
  opacity: var(--fa-secondary-opacity, 0.4);
}

.svg-inline--fa.fa-swap-opacity .fa-primary {
  opacity: var(--fa-secondary-opacity, 0.4);
}

.svg-inline--fa.fa-swap-opacity .fa-secondary {
  opacity: var(--fa-primary-opacity, 1);
}

.svg-inline--fa mask .fa-primary,
.svg-inline--fa mask .fa-secondary {
  fill: black;
}

.fad.fa-inverse,
.fa-duotone.fa-inverse {
  color: var(--fa-inverse, #fff);
}`;function Yo(){var t=jo,e=Do,n=P.cssPrefix,r=P.replacementClass,i=mc;if(n!==t||r!==e){var a=new RegExp("\\.".concat(t,"\\-"),"g"),o=new RegExp("\\--".concat(t,"\\-"),"g"),s=new RegExp("\\.".concat(e),"g");i=i.replace(a,".".concat(n,"-")).replace(o,"--".concat(n,"-")).replace(s,".".concat(r))}return i}var da=!1;function ur(){P.autoAddCss&&!da&&(lc(Yo()),da=!0)}var hc={mixout:function(){return{dom:{css:Yo,insertCss:ur}}},hooks:function(){return{beforeDOMElementCreation:function(){ur()},beforeI2svg:function(){ur()}}}},jt=Xt||{};jt[Ft]||(jt[Ft]={});jt[Ft].styles||(jt[Ft].styles={});jt[Ft].hooks||(jt[Ft].hooks={});jt[Ft].shims||(jt[Ft].shims=[]);var _t=jt[Ft],Wo=[],pc=function t(){G.removeEventListener("DOMContentLoaded",t),Fn=1,Wo.map(function(e){return e()})},Fn=!1;zt&&(Fn=(G.documentElement.doScroll?/^loaded|^c/:/^loaded|^i|^c/).test(G.readyState),Fn||G.addEventListener("DOMContentLoaded",pc));function gc(t){zt&&(Fn?setTimeout(t,0):Wo.push(t))}function tn(t){var e=t.tag,n=t.attributes,r=n===void 0?{}:n,i=t.children,a=i===void 0?[]:i;return typeof t=="string"?Bo(t):"<".concat(e," ").concat(cc(r),">").concat(a.map(tn).join(""),"</").concat(e,">")}function ma(t,e,n){if(t&&t[e]&&t[e][n])return{prefix:e,iconName:n,icon:t[e][n]}}var dr=function(e,n,r,i){var a=Object.keys(e),o=a.length,s=n,l,c,u;for(r===void 0?(l=1,u=e[a[0]]):(l=0,u=r);l<o;l++)c=a[l],u=s(u,e[c],c,e);return u};function vc(t){for(var e=[],n=0,r=t.length;n<r;){var i=t.charCodeAt(n++);if(i>=55296&&i<=56319&&n<r){var a=t.charCodeAt(n++);(a&64512)==56320?e.push(((i&1023)<<10)+(a&1023)+65536):(e.push(i),n--)}else e.push(i)}return e}function Nr(t){var e=vc(t);return e.length===1?e[0].toString(16):null}function bc(t,e){var n=t.length,r=t.charCodeAt(e),i;return r>=55296&&r<=56319&&n>e+1&&(i=t.charCodeAt(e+1),i>=56320&&i<=57343)?(r-55296)*1024+i-56320+65536:r}function ha(t){return Object.keys(t).reduce(function(e,n){var r=t[n],i=!!r.icon;return i?e[r.iconName]=r.icon:e[n]=r,e},{})}function Mr(t,e){var n=arguments.length>2&&arguments[2]!==void 0?arguments[2]:{},r=n.skipHooks,i=r===void 0?!1:r,a=ha(e);typeof _t.hooks.addPack=="function"&&!i?_t.hooks.addPack(t,ha(e)):_t.styles[t]=E(E({},_t.styles[t]||{}),a),t==="fas"&&Mr("fa",e)}var bn,yn,xn,ve=_t.styles,yc=_t.shims,xc=(bn={},et(bn,K,Object.values(Ge[K])),et(bn,Z,Object.values(Ge[Z])),bn),mi=null,Vo={},Ko={},Go={},Xo={},qo={},wc=(yn={},et(yn,K,Object.keys(Ve[K])),et(yn,Z,Object.keys(Ve[Z])),yn);function _c(t){return~rc.indexOf(t)}function Ac(t,e){var n=e.split("-"),r=n[0],i=n.slice(1).join("-");return r===t&&i!==""&&!_c(i)?i:null}var Jo=function(){var e=function(a){return dr(ve,function(o,s,l){return o[l]=dr(s,a,{}),o},{})};Vo=e(function(i,a,o){if(a[3]&&(i[a[3]]=o),a[2]){var s=a[2].filter(function(l){return typeof l=="number"});s.forEach(function(l){i[l.toString(16)]=o})}return i}),Ko=e(function(i,a,o){if(i[o]=o,a[2]){var s=a[2].filter(function(l){return typeof l=="string"});s.forEach(function(l){i[l]=o})}return i}),qo=e(function(i,a,o){var s=a[2];return i[o]=o,s.forEach(function(l){i[l]=o}),i});var n="far"in ve||P.autoFetchSvg,r=dr(yc,function(i,a){var o=a[0],s=a[1],l=a[2];return s==="far"&&!n&&(s="fas"),typeof o=="string"&&(i.names[o]={prefix:s,iconName:l}),typeof o=="number"&&(i.unicodes[o.toString(16)]={prefix:s,iconName:l}),i},{names:{},unicodes:{}});Go=r.names,Xo=r.unicodes,mi=Jn(P.styleDefault,{family:P.familyDefault})};sc(function(t){mi=Jn(t.styleDefault,{family:P.familyDefault})});Jo();function hi(t,e){return(Vo[t]||{})[e]}function Oc(t,e){return(Ko[t]||{})[e]}function le(t,e){return(qo[t]||{})[e]}function Zo(t){return Go[t]||{prefix:null,iconName:null}}function kc(t){var e=Xo[t],n=hi("fas",t);return e||(n?{prefix:"fas",iconName:n}:null)||{prefix:null,iconName:null}}function qt(){return mi}var pi=function(){return{prefix:null,iconName:null,rest:[]}};function Jn(t){var e=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},n=e.family,r=n===void 0?K:n,i=Ve[r][t],a=Ke[r][t]||Ke[r][i],o=t in _t.styles?t:null;return a||o||null}var pa=(xn={},et(xn,K,Object.keys(Ge[K])),et(xn,Z,Object.keys(Ge[Z])),xn);function Zn(t){var e,n=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},r=n.skipLookups,i=r===void 0?!1:r,a=(e={},et(e,K,"".concat(P.cssPrefix,"-").concat(K)),et(e,Z,"".concat(P.cssPrefix,"-").concat(Z)),e),o=null,s=K;(t.includes(a[K])||t.some(function(c){return pa[K].includes(c)}))&&(s=K),(t.includes(a[Z])||t.some(function(c){return pa[Z].includes(c)}))&&(s=Z);var l=t.reduce(function(c,u){var m=Ac(P.cssPrefix,u);if(ve[u]?(u=xc[s].includes(u)?Jf[s][u]:u,o=u,c.prefix=u):wc[s].indexOf(u)>-1?(o=u,c.prefix=Jn(u,{family:s})):m?c.iconName=m:u!==P.replacementClass&&u!==a[K]&&u!==a[Z]&&c.rest.push(u),!i&&c.prefix&&c.iconName){var v=o==="fa"?Zo(c.iconName):{},_=le(c.prefix,c.iconName);v.prefix&&(o=null),c.iconName=v.iconName||_||c.iconName,c.prefix=v.prefix||c.prefix,c.prefix==="far"&&!ve.far&&ve.fas&&!P.autoFetchSvg&&(c.prefix="fas")}return c},pi());return(t.includes("fa-brands")||t.includes("fab"))&&(l.prefix="fab"),(t.includes("fa-duotone")||t.includes("fad"))&&(l.prefix="fad"),!l.prefix&&s===Z&&(ve.fass||P.autoFetchSvg)&&(l.prefix="fass",l.iconName=le(l.prefix,l.iconName)||l.iconName),(l.prefix==="fa"||o==="fa")&&(l.prefix=qt()||"fas"),l}var Ec=function(){function t(){Df(this,t),this.definitions={}}return zf(t,[{key:"add",value:function(){for(var n=this,r=arguments.length,i=new Array(r),a=0;a<r;a++)i[a]=arguments[a];var o=i.reduce(this._pullDefinitions,{});Object.keys(o).forEach(function(s){n.definitions[s]=E(E({},n.definitions[s]||{}),o[s]),Mr(s,o[s]);var l=Ge[K][s];l&&Mr(l,o[s]),Jo()})}},{key:"reset",value:function(){this.definitions={}}},{key:"_pullDefinitions",value:function(n,r){var i=r.prefix&&r.iconName&&r.icon?{0:r}:r;return Object.keys(i).map(function(a){var o=i[a],s=o.prefix,l=o.iconName,c=o.icon,u=c[2];n[s]||(n[s]={}),u.length>0&&u.forEach(function(m){typeof m=="string"&&(n[s][m]=c)}),n[s][l]=c}),n}}]),t}(),ga=[],be={},_e={},Sc=Object.keys(_e);function Pc(t,e){var n=e.mixoutsTo;return ga=t,be={},Object.keys(_e).forEach(function(r){Sc.indexOf(r)===-1&&delete _e[r]}),ga.forEach(function(r){var i=r.mixout?r.mixout():{};if(Object.keys(i).forEach(function(o){typeof i[o]=="function"&&(n[o]=i[o]),Ln(i[o])==="object"&&Object.keys(i[o]).forEach(function(s){n[o]||(n[o]={}),n[o][s]=i[o][s]})}),r.hooks){var a=r.hooks();Object.keys(a).forEach(function(o){be[o]||(be[o]=[]),be[o].push(a[o])})}r.provides&&r.provides(_e)}),n}function Rr(t,e){for(var n=arguments.length,r=new Array(n>2?n-2:0),i=2;i<n;i++)r[i-2]=arguments[i];var a=be[t]||[];return a.forEach(function(o){e=o.apply(null,[e].concat(r))}),e}function me(t){for(var e=arguments.length,n=new Array(e>1?e-1:0),r=1;r<e;r++)n[r-1]=arguments[r];var i=be[t]||[];i.forEach(function(a){a.apply(null,n)})}function Dt(){var t=arguments[0],e=Array.prototype.slice.call(arguments,1);return _e[t]?_e[t].apply(null,e):void 0}function Lr(t){t.prefix==="fa"&&(t.prefix="fas");var e=t.iconName,n=t.prefix||qt();if(e)return e=le(n,e)||e,ma(Qo.definitions,n,e)||ma(_t.styles,n,e)}var Qo=new Ec,Cc=function(){P.autoReplaceSvg=!1,P.observeMutations=!1,me("noAuto")},Ic={i2svg:function(){var e=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{};return zt?(me("beforeI2svg",e),Dt("pseudoElements2svg",e),Dt("i2svg",e)):Promise.reject("Operation requires a DOM of some kind.")},watch:function(){var e=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{},n=e.autoReplaceSvgRoot;P.autoReplaceSvg===!1&&(P.autoReplaceSvg=!0),P.observeMutations=!0,gc(function(){Nc({autoReplaceSvgRoot:n}),me("watch",e)})}},Tc={icon:function(e){if(e===null)return null;if(Ln(e)==="object"&&e.prefix&&e.iconName)return{prefix:e.prefix,iconName:le(e.prefix,e.iconName)||e.iconName};if(Array.isArray(e)&&e.length===2){var n=e[1].indexOf("fa-")===0?e[1].slice(3):e[1],r=Jn(e[0]);return{prefix:r,iconName:le(r,n)||n}}if(typeof e=="string"&&(e.indexOf("".concat(P.cssPrefix,"-"))>-1||e.match(Zf))){var i=Zn(e.split(" "),{skipLookups:!0});return{prefix:i.prefix||qt(),iconName:le(i.prefix,i.iconName)||i.iconName}}if(typeof e=="string"){var a=qt();return{prefix:a,iconName:le(a,e)||e}}}},gt={noAuto:Cc,config:P,dom:Ic,parse:Tc,library:Qo,findIconDefinition:Lr,toHtml:tn},Nc=function(){var e=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{},n=e.autoReplaceSvgRoot,r=n===void 0?G:n;(Object.keys(_t.styles).length>0||P.autoFetchSvg)&&zt&&P.autoReplaceSvg&&gt.dom.i2svg({node:r})};function Qn(t,e){return Object.defineProperty(t,"abstract",{get:e}),Object.defineProperty(t,"html",{get:function(){return t.abstract.map(function(r){return tn(r)})}}),Object.defineProperty(t,"node",{get:function(){if(zt){var r=G.createElement("div");return r.innerHTML=t.html,r.children}}}),t}function Mc(t){var e=t.children,n=t.main,r=t.mask,i=t.attributes,a=t.styles,o=t.transform;if(di(o)&&n.found&&!r.found){var s=n.width,l=n.height,c={x:s/l/2,y:.5};i.style=qn(E(E({},a),{},{"transform-origin":"".concat(c.x+o.x/16,"em ").concat(c.y+o.y/16,"em")}))}return[{tag:"svg",attributes:i,children:e}]}function Rc(t){var e=t.prefix,n=t.iconName,r=t.children,i=t.attributes,a=t.symbol,o=a===!0?"".concat(e,"-").concat(P.cssPrefix,"-").concat(n):a;return[{tag:"svg",attributes:{style:"display: none;"},children:[{tag:"symbol",attributes:E(E({},i),{},{id:o}),children:r}]}]}function gi(t){var e=t.icons,n=e.main,r=e.mask,i=t.prefix,a=t.iconName,o=t.transform,s=t.symbol,l=t.title,c=t.maskId,u=t.titleId,m=t.extra,v=t.watchable,_=v===void 0?!1:v,j=r.found?r:n,N=j.width,B=j.height,A=i==="fak",k=[P.replacementClass,a?"".concat(P.cssPrefix,"-").concat(a):""].filter(function(vt){return m.classes.indexOf(vt)===-1}).filter(function(vt){return vt!==""||!!vt}).concat(m.classes).join(" "),C={children:[],attributes:E(E({},m.attributes),{},{"data-prefix":i,"data-icon":a,class:k,role:m.attributes.role||"img",xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 ".concat(N," ").concat(B)})},D=A&&!~m.classes.indexOf("fa-fw")?{width:"".concat(N/B*16*.0625,"em")}:{};_&&(C.attributes[de]=""),l&&(C.children.push({tag:"title",attributes:{id:C.attributes["aria-labelledby"]||"title-".concat(u||qe())},children:[l]}),delete C.attributes.title);var U=E(E({},C),{},{prefix:i,iconName:a,main:n,mask:r,maskId:c,transform:o,symbol:s,styles:E(E({},D),m.styles)}),L=r.found&&n.found?Dt("generateAbstractMask",U)||{children:[],attributes:{}}:Dt("generateAbstractIcon",U)||{children:[],attributes:{}},Q=L.children,lt=L.attributes;return U.children=Q,U.attributes=lt,s?Rc(U):Mc(U)}function va(t){var e=t.content,n=t.width,r=t.height,i=t.transform,a=t.title,o=t.extra,s=t.watchable,l=s===void 0?!1:s,c=E(E(E({},o.attributes),a?{title:a}:{}),{},{class:o.classes.join(" ")});l&&(c[de]="");var u=E({},o.styles);di(i)&&(u.transform=dc({transform:i,startCentered:!0,width:n,height:r}),u["-webkit-transform"]=u.transform);var m=qn(u);m.length>0&&(c.style=m);var v=[];return v.push({tag:"span",attributes:c,children:[e]}),a&&v.push({tag:"span",attributes:{class:"sr-only"},children:[a]}),v}function Lc(t){var e=t.content,n=t.title,r=t.extra,i=E(E(E({},r.attributes),n?{title:n}:{}),{},{class:r.classes.join(" ")}),a=qn(r.styles);a.length>0&&(i.style=a);var o=[];return o.push({tag:"span",attributes:i,children:[e]}),n&&o.push({tag:"span",attributes:{class:"sr-only"},children:[n]}),o}var mr=_t.styles;function Fr(t){var e=t[0],n=t[1],r=t.slice(4),i=oi(r,1),a=i[0],o=null;return Array.isArray(a)?o={tag:"g",attributes:{class:"".concat(P.cssPrefix,"-").concat(se.GROUP)},children:[{tag:"path",attributes:{class:"".concat(P.cssPrefix,"-").concat(se.SECONDARY),fill:"currentColor",d:a[0]}},{tag:"path",attributes:{class:"".concat(P.cssPrefix,"-").concat(se.PRIMARY),fill:"currentColor",d:a[1]}}]}:o={tag:"path",attributes:{fill:"currentColor",d:a}},{found:!0,width:e,height:n,icon:o}}var Fc={found:!1,width:512,height:512};function jc(t,e){!$o&&!P.showMissingIcons&&t&&console.error('Icon with name "'.concat(t,'" and prefix "').concat(e,'" is missing.'))}function jr(t,e){var n=e;return e==="fa"&&P.styleDefault!==null&&(e=qt()),new Promise(function(r,i){if(Dt("missingIconAbstract"),n==="fa"){var a=Zo(t)||{};t=a.iconName||t,e=a.prefix||e}if(t&&e&&mr[e]&&mr[e][t]){var o=mr[e][t];return r(Fr(o))}jc(t,e),r(E(E({},Fc),{},{icon:P.showMissingIcons&&t?Dt("missingIconAbstract")||{}:{}}))})}var ba=function(){},Dr=P.measurePerformance&&dn&&dn.mark&&dn.measure?dn:{mark:ba,measure:ba},Me='FA "6.5.2"',Dc=function(e){return Dr.mark("".concat(Me," ").concat(e," begins")),function(){return ts(e)}},ts=function(e){Dr.mark("".concat(Me," ").concat(e," ends")),Dr.measure("".concat(Me," ").concat(e),"".concat(Me," ").concat(e," begins"),"".concat(Me," ").concat(e," ends"))},vi={begin:Dc,end:ts},Pn=function(){};function ya(t){var e=t.getAttribute?t.getAttribute(de):null;return typeof e=="string"}function $c(t){var e=t.getAttribute?t.getAttribute(li):null,n=t.getAttribute?t.getAttribute(fi):null;return e&&n}function zc(t){return t&&t.classList&&t.classList.contains&&t.classList.contains(P.replacementClass)}function Uc(){if(P.autoReplaceSvg===!0)return Cn.replace;var t=Cn[P.autoReplaceSvg];return t||Cn.replace}function Hc(t){return G.createElementNS("http://www.w3.org/2000/svg",t)}function Bc(t){return G.createElement(t)}function es(t){var e=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},n=e.ceFn,r=n===void 0?t.tag==="svg"?Hc:Bc:n;if(typeof t=="string")return G.createTextNode(t);var i=r(t.tag);Object.keys(t.attributes||[]).forEach(function(o){i.setAttribute(o,t.attributes[o])});var a=t.children||[];return a.forEach(function(o){i.appendChild(es(o,{ceFn:r}))}),i}function Yc(t){var e=" ".concat(t.outerHTML," ");return e="".concat(e,"Font Awesome fontawesome.com "),e}var Cn={replace:function(e){var n=e[0];if(n.parentNode)if(e[1].forEach(function(i){n.parentNode.insertBefore(es(i),n)}),n.getAttribute(de)===null&&P.keepOriginalSource){var r=G.createComment(Yc(n));n.parentNode.replaceChild(r,n)}else n.remove()},nest:function(e){var n=e[0],r=e[1];if(~ui(n).indexOf(P.replacementClass))return Cn.replace(e);var i=new RegExp("".concat(P.cssPrefix,"-.*"));if(delete r[0].attributes.id,r[0].attributes.class){var a=r[0].attributes.class.split(" ").reduce(function(s,l){return l===P.replacementClass||l.match(i)?s.toSvg.push(l):s.toNode.push(l),s},{toNode:[],toSvg:[]});r[0].attributes.class=a.toSvg.join(" "),a.toNode.length===0?n.removeAttribute("class"):n.setAttribute("class",a.toNode.join(" "))}var o=r.map(function(s){return tn(s)}).join(`
`);n.setAttribute(de,""),n.innerHTML=o}};function xa(t){t()}function ns(t,e){var n=typeof e=="function"?e:Pn;if(t.length===0)n();else{var r=xa;P.mutateApproach===Xf&&(r=Xt.requestAnimationFrame||xa),r(function(){var i=Uc(),a=vi.begin("mutate");t.map(i),a(),n()})}}var bi=!1;function rs(){bi=!0}function $r(){bi=!1}var jn=null;function wa(t){if(ca&&P.observeMutations){var e=t.treeCallback,n=e===void 0?Pn:e,r=t.nodeCallback,i=r===void 0?Pn:r,a=t.pseudoElementsCallback,o=a===void 0?Pn:a,s=t.observeMutationsRoot,l=s===void 0?G:s;jn=new ca(function(c){if(!bi){var u=qt();Ee(c).forEach(function(m){if(m.type==="childList"&&m.addedNodes.length>0&&!ya(m.addedNodes[0])&&(P.searchPseudoElements&&o(m.target),n(m.target)),m.type==="attributes"&&m.target.parentNode&&P.searchPseudoElements&&o(m.target.parentNode),m.type==="attributes"&&ya(m.target)&&~nc.indexOf(m.attributeName))if(m.attributeName==="class"&&$c(m.target)){var v=Zn(ui(m.target)),_=v.prefix,j=v.iconName;m.target.setAttribute(li,_||u),j&&m.target.setAttribute(fi,j)}else zc(m.target)&&i(m.target)})}}),zt&&jn.observe(l,{childList:!0,attributes:!0,characterData:!0,subtree:!0})}}function Wc(){jn&&jn.disconnect()}function Vc(t){var e=t.getAttribute("style"),n=[];return e&&(n=e.split(";").reduce(function(r,i){var a=i.split(":"),o=a[0],s=a.slice(1);return o&&s.length>0&&(r[o]=s.join(":").trim()),r},{})),n}function Kc(t){var e=t.getAttribute("data-prefix"),n=t.getAttribute("data-icon"),r=t.innerText!==void 0?t.innerText.trim():"",i=Zn(ui(t));return i.prefix||(i.prefix=qt()),e&&n&&(i.prefix=e,i.iconName=n),i.iconName&&i.prefix||(i.prefix&&r.length>0&&(i.iconName=Oc(i.prefix,t.innerText)||hi(i.prefix,Nr(t.innerText))),!i.iconName&&P.autoFetchSvg&&t.firstChild&&t.firstChild.nodeType===Node.TEXT_NODE&&(i.iconName=t.firstChild.data)),i}function Gc(t){var e=Ee(t.attributes).reduce(function(i,a){return i.name!=="class"&&i.name!=="style"&&(i[a.name]=a.value),i},{}),n=t.getAttribute("title"),r=t.getAttribute("data-fa-title-id");return P.autoA11y&&(n?e["aria-labelledby"]="".concat(P.replacementClass,"-title-").concat(r||qe()):(e["aria-hidden"]="true",e.focusable="false")),e}function Xc(){return{iconName:null,title:null,titleId:null,prefix:null,transform:Ct,symbol:!1,mask:{iconName:null,prefix:null,rest:[]},maskId:null,extra:{classes:[],styles:{},attributes:{}}}}function _a(t){var e=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{styleParser:!0},n=Kc(t),r=n.iconName,i=n.prefix,a=n.rest,o=Gc(t),s=Rr("parseNodeAttributes",{},t),l=e.styleParser?Vc(t):[];return E({iconName:r,title:t.getAttribute("title"),titleId:t.getAttribute("data-fa-title-id"),prefix:i,transform:Ct,mask:{iconName:null,prefix:null,rest:[]},maskId:null,symbol:!1,extra:{classes:a,styles:l,attributes:o}},s)}var qc=_t.styles;function is(t){var e=P.autoReplaceSvg==="nest"?_a(t,{styleParser:!1}):_a(t);return~e.extra.classes.indexOf(zo)?Dt("generateLayersText",t,e):Dt("generateSvgReplacementMutation",t,e)}var Jt=new Set;ci.map(function(t){Jt.add("fa-".concat(t))});Object.keys(Ve[K]).map(Jt.add.bind(Jt));Object.keys(Ve[Z]).map(Jt.add.bind(Jt));Jt=Ze(Jt);function Aa(t){var e=arguments.length>1&&arguments[1]!==void 0?arguments[1]:null;if(!zt)return Promise.resolve();var n=G.documentElement.classList,r=function(m){return n.add("".concat(ua,"-").concat(m))},i=function(m){return n.remove("".concat(ua,"-").concat(m))},a=P.autoFetchSvg?Jt:ci.map(function(u){return"fa-".concat(u)}).concat(Object.keys(qc));a.includes("fa")||a.push("fa");var o=[".".concat(zo,":not([").concat(de,"])")].concat(a.map(function(u){return".".concat(u,":not([").concat(de,"])")})).join(", ");if(o.length===0)return Promise.resolve();var s=[];try{s=Ee(t.querySelectorAll(o))}catch{}if(s.length>0)r("pending"),i("complete");else return Promise.resolve();var l=vi.begin("onTree"),c=s.reduce(function(u,m){try{var v=is(m);v&&u.push(v)}catch(_){$o||_.name==="MissingIcon"&&console.error(_)}return u},[]);return new Promise(function(u,m){Promise.all(c).then(function(v){ns(v,function(){r("active"),r("complete"),i("pending"),typeof e=="function"&&e(),l(),u()})}).catch(function(v){l(),m(v)})})}function Jc(t){var e=arguments.length>1&&arguments[1]!==void 0?arguments[1]:null;is(t).then(function(n){n&&ns([n],e)})}function Zc(t){return function(e){var n=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},r=(e||{}).icon?e:Lr(e||{}),i=n.mask;return i&&(i=(i||{}).icon?i:Lr(i||{})),t(r,E(E({},n),{},{mask:i}))}}var Qc=function(e){var n=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},r=n.transform,i=r===void 0?Ct:r,a=n.symbol,o=a===void 0?!1:a,s=n.mask,l=s===void 0?null:s,c=n.maskId,u=c===void 0?null:c,m=n.title,v=m===void 0?null:m,_=n.titleId,j=_===void 0?null:_,N=n.classes,B=N===void 0?[]:N,A=n.attributes,k=A===void 0?{}:A,C=n.styles,D=C===void 0?{}:C;if(e){var U=e.prefix,L=e.iconName,Q=e.icon;return Qn(E({type:"icon"},e),function(){return me("beforeDOMElementCreation",{iconDefinition:e,params:n}),P.autoA11y&&(v?k["aria-labelledby"]="".concat(P.replacementClass,"-title-").concat(j||qe()):(k["aria-hidden"]="true",k.focusable="false")),gi({icons:{main:Fr(Q),mask:l?Fr(l.icon):{found:!1,width:null,height:null,icon:{}}},prefix:U,iconName:L,transform:E(E({},Ct),i),symbol:o,title:v,maskId:u,titleId:j,extra:{attributes:k,styles:D,classes:B}})})}},tu={mixout:function(){return{icon:Zc(Qc)}},hooks:function(){return{mutationObserverCallbacks:function(n){return n.treeCallback=Aa,n.nodeCallback=Jc,n}}},provides:function(e){e.i2svg=function(n){var r=n.node,i=r===void 0?G:r,a=n.callback,o=a===void 0?function(){}:a;return Aa(i,o)},e.generateSvgReplacementMutation=function(n,r){var i=r.iconName,a=r.title,o=r.titleId,s=r.prefix,l=r.transform,c=r.symbol,u=r.mask,m=r.maskId,v=r.extra;return new Promise(function(_,j){Promise.all([jr(i,s),u.iconName?jr(u.iconName,u.prefix):Promise.resolve({found:!1,width:512,height:512,icon:{}})]).then(function(N){var B=oi(N,2),A=B[0],k=B[1];_([n,gi({icons:{main:A,mask:k},prefix:s,iconName:i,transform:l,symbol:c,maskId:m,title:a,titleId:o,extra:v,watchable:!0})])}).catch(j)})},e.generateAbstractIcon=function(n){var r=n.children,i=n.attributes,a=n.main,o=n.transform,s=n.styles,l=qn(s);l.length>0&&(i.style=l);var c;return di(o)&&(c=Dt("generateAbstractTransformGrouping",{main:a,transform:o,containerWidth:a.width,iconWidth:a.width})),r.push(c||a.icon),{children:r,attributes:i}}}},eu={mixout:function(){return{layer:function(n){var r=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},i=r.classes,a=i===void 0?[]:i;return Qn({type:"layer"},function(){me("beforeDOMElementCreation",{assembler:n,params:r});var o=[];return n(function(s){Array.isArray(s)?s.map(function(l){o=o.concat(l.abstract)}):o=o.concat(s.abstract)}),[{tag:"span",attributes:{class:["".concat(P.cssPrefix,"-layers")].concat(Ze(a)).join(" ")},children:o}]})}}}},nu={mixout:function(){return{counter:function(n){var r=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},i=r.title,a=i===void 0?null:i,o=r.classes,s=o===void 0?[]:o,l=r.attributes,c=l===void 0?{}:l,u=r.styles,m=u===void 0?{}:u;return Qn({type:"counter",content:n},function(){return me("beforeDOMElementCreation",{content:n,params:r}),Lc({content:n.toString(),title:a,extra:{attributes:c,styles:m,classes:["".concat(P.cssPrefix,"-layers-counter")].concat(Ze(s))}})})}}}},ru={mixout:function(){return{text:function(n){var r=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},i=r.transform,a=i===void 0?Ct:i,o=r.title,s=o===void 0?null:o,l=r.classes,c=l===void 0?[]:l,u=r.attributes,m=u===void 0?{}:u,v=r.styles,_=v===void 0?{}:v;return Qn({type:"text",content:n},function(){return me("beforeDOMElementCreation",{content:n,params:r}),va({content:n,transform:E(E({},Ct),a),title:s,extra:{attributes:m,styles:_,classes:["".concat(P.cssPrefix,"-layers-text")].concat(Ze(c))}})})}}},provides:function(e){e.generateLayersText=function(n,r){var i=r.title,a=r.transform,o=r.extra,s=null,l=null;if(Fo){var c=parseInt(getComputedStyle(n).fontSize,10),u=n.getBoundingClientRect();s=u.width/c,l=u.height/c}return P.autoA11y&&!i&&(o.attributes["aria-hidden"]="true"),Promise.resolve([n,va({content:n.innerHTML,width:s,height:l,transform:a,title:i,extra:o,watchable:!0})])}}},iu=new RegExp('"',"ug"),Oa=[1105920,1112319];function au(t){var e=t.replace(iu,""),n=bc(e,0),r=n>=Oa[0]&&n<=Oa[1],i=e.length===2?e[0]===e[1]:!1;return{value:Nr(i?e[0]:e),isSecondary:r||i}}function ka(t,e){var n="".concat(Gf).concat(e.replace(":","-"));return new Promise(function(r,i){if(t.getAttribute(n)!==null)return r();var a=Ee(t.children),o=a.filter(function(Q){return Q.getAttribute(Tr)===e})[0],s=Xt.getComputedStyle(t,e),l=s.getPropertyValue("font-family").match(Qf),c=s.getPropertyValue("font-weight"),u=s.getPropertyValue("content");if(o&&!l)return t.removeChild(o),r();if(l&&u!=="none"&&u!==""){var m=s.getPropertyValue("content"),v=~["Sharp"].indexOf(l[2])?Z:K,_=~["Solid","Regular","Light","Thin","Duotone","Brands","Kit"].indexOf(l[2])?Ke[v][l[2].toLowerCase()]:tc[v][c],j=au(m),N=j.value,B=j.isSecondary,A=l[0].startsWith("FontAwesome"),k=hi(_,N),C=k;if(A){var D=kc(N);D.iconName&&D.prefix&&(k=D.iconName,_=D.prefix)}if(k&&!B&&(!o||o.getAttribute(li)!==_||o.getAttribute(fi)!==C)){t.setAttribute(n,C),o&&t.removeChild(o);var U=Xc(),L=U.extra;L.attributes[Tr]=e,jr(k,_).then(function(Q){var lt=gi(E(E({},U),{},{icons:{main:Q,mask:pi()},prefix:_,iconName:C,extra:L,watchable:!0})),vt=G.createElementNS("http://www.w3.org/2000/svg","svg");e==="::before"?t.insertBefore(vt,t.firstChild):t.appendChild(vt),vt.outerHTML=lt.map(function(Tt){return tn(Tt)}).join(`
`),t.removeAttribute(n),r()}).catch(i)}else r()}else r()})}function ou(t){return Promise.all([ka(t,"::before"),ka(t,"::after")])}function su(t){return t.parentNode!==document.head&&!~qf.indexOf(t.tagName.toUpperCase())&&!t.getAttribute(Tr)&&(!t.parentNode||t.parentNode.tagName!=="svg")}function Ea(t){if(zt)return new Promise(function(e,n){var r=Ee(t.querySelectorAll("*")).filter(su).map(ou),i=vi.begin("searchPseudoElements");rs(),Promise.all(r).then(function(){i(),$r(),e()}).catch(function(){i(),$r(),n()})})}var lu={hooks:function(){return{mutationObserverCallbacks:function(n){return n.pseudoElementsCallback=Ea,n}}},provides:function(e){e.pseudoElements2svg=function(n){var r=n.node,i=r===void 0?G:r;P.searchPseudoElements&&Ea(i)}}},Sa=!1,fu={mixout:function(){return{dom:{unwatch:function(){rs(),Sa=!0}}}},hooks:function(){return{bootstrap:function(){wa(Rr("mutationObserverCallbacks",{}))},noAuto:function(){Wc()},watch:function(n){var r=n.observeMutationsRoot;Sa?$r():wa(Rr("mutationObserverCallbacks",{observeMutationsRoot:r}))}}}},Pa=function(e){var n={size:16,x:0,y:0,flipX:!1,flipY:!1,rotate:0};return e.toLowerCase().split(" ").reduce(function(r,i){var a=i.toLowerCase().split("-"),o=a[0],s=a.slice(1).join("-");if(o&&s==="h")return r.flipX=!0,r;if(o&&s==="v")return r.flipY=!0,r;if(s=parseFloat(s),isNaN(s))return r;switch(o){case"grow":r.size=r.size+s;break;case"shrink":r.size=r.size-s;break;case"left":r.x=r.x-s;break;case"right":r.x=r.x+s;break;case"up":r.y=r.y-s;break;case"down":r.y=r.y+s;break;case"rotate":r.rotate=r.rotate+s;break}return r},n)},cu={mixout:function(){return{parse:{transform:function(n){return Pa(n)}}}},hooks:function(){return{parseNodeAttributes:function(n,r){var i=r.getAttribute("data-fa-transform");return i&&(n.transform=Pa(i)),n}}},provides:function(e){e.generateAbstractTransformGrouping=function(n){var r=n.main,i=n.transform,a=n.containerWidth,o=n.iconWidth,s={transform:"translate(".concat(a/2," 256)")},l="translate(".concat(i.x*32,", ").concat(i.y*32,") "),c="scale(".concat(i.size/16*(i.flipX?-1:1),", ").concat(i.size/16*(i.flipY?-1:1),") "),u="rotate(".concat(i.rotate," 0 0)"),m={transform:"".concat(l," ").concat(c," ").concat(u)},v={transform:"translate(".concat(o/2*-1," -256)")},_={outer:s,inner:m,path:v};return{tag:"g",attributes:E({},_.outer),children:[{tag:"g",attributes:E({},_.inner),children:[{tag:r.icon.tag,children:r.icon.children,attributes:E(E({},r.icon.attributes),_.path)}]}]}}}},hr={x:0,y:0,width:"100%",height:"100%"};function Ca(t){var e=arguments.length>1&&arguments[1]!==void 0?arguments[1]:!0;return t.attributes&&(t.attributes.fill||e)&&(t.attributes.fill="black"),t}function uu(t){return t.tag==="g"?t.children:[t]}var du={hooks:function(){return{parseNodeAttributes:function(n,r){var i=r.getAttribute("data-fa-mask"),a=i?Zn(i.split(" ").map(function(o){return o.trim()})):pi();return a.prefix||(a.prefix=qt()),n.mask=a,n.maskId=r.getAttribute("data-fa-mask-id"),n}}},provides:function(e){e.generateAbstractMask=function(n){var r=n.children,i=n.attributes,a=n.main,o=n.mask,s=n.maskId,l=n.transform,c=a.width,u=a.icon,m=o.width,v=o.icon,_=uc({transform:l,containerWidth:m,iconWidth:c}),j={tag:"rect",attributes:E(E({},hr),{},{fill:"white"})},N=u.children?{children:u.children.map(Ca)}:{},B={tag:"g",attributes:E({},_.inner),children:[Ca(E({tag:u.tag,attributes:E(E({},u.attributes),_.path)},N))]},A={tag:"g",attributes:E({},_.outer),children:[B]},k="mask-".concat(s||qe()),C="clip-".concat(s||qe()),D={tag:"mask",attributes:E(E({},hr),{},{id:k,maskUnits:"userSpaceOnUse",maskContentUnits:"userSpaceOnUse"}),children:[j,A]},U={tag:"defs",children:[{tag:"clipPath",attributes:{id:C},children:uu(v)},D]};return r.push(U,{tag:"rect",attributes:E({fill:"currentColor","clip-path":"url(#".concat(C,")"),mask:"url(#".concat(k,")")},hr)}),{children:r,attributes:i}}}},mu={provides:function(e){var n=!1;Xt.matchMedia&&(n=Xt.matchMedia("(prefers-reduced-motion: reduce)").matches),e.missingIconAbstract=function(){var r=[],i={fill:"currentColor"},a={attributeType:"XML",repeatCount:"indefinite",dur:"2s"};r.push({tag:"path",attributes:E(E({},i),{},{d:"M156.5,447.7l-12.6,29.5c-18.7-9.5-35.9-21.2-51.5-34.9l22.7-22.7C127.6,430.5,141.5,440,156.5,447.7z M40.6,272H8.5 c1.4,21.2,5.4,41.7,11.7,61.1L50,321.2C45.1,305.5,41.8,289,40.6,272z M40.6,240c1.4-18.8,5.2-37,11.1-54.1l-29.5-12.6 C14.7,194.3,10,216.7,8.5,240H40.6z M64.3,156.5c7.8-14.9,17.2-28.8,28.1-41.5L69.7,92.3c-13.7,15.6-25.5,32.8-34.9,51.5 L64.3,156.5z M397,419.6c-13.9,12-29.4,22.3-46.1,30.4l11.9,29.8c20.7-9.9,39.8-22.6,56.9-37.6L397,419.6z M115,92.4 c13.9-12,29.4-22.3,46.1-30.4l-11.9-29.8c-20.7,9.9-39.8,22.6-56.8,37.6L115,92.4z M447.7,355.5c-7.8,14.9-17.2,28.8-28.1,41.5 l22.7,22.7c13.7-15.6,25.5-32.9,34.9-51.5L447.7,355.5z M471.4,272c-1.4,18.8-5.2,37-11.1,54.1l29.5,12.6 c7.5-21.1,12.2-43.5,13.6-66.8H471.4z M321.2,462c-15.7,5-32.2,8.2-49.2,9.4v32.1c21.2-1.4,41.7-5.4,61.1-11.7L321.2,462z M240,471.4c-18.8-1.4-37-5.2-54.1-11.1l-12.6,29.5c21.1,7.5,43.5,12.2,66.8,13.6V471.4z M462,190.8c5,15.7,8.2,32.2,9.4,49.2h32.1 c-1.4-21.2-5.4-41.7-11.7-61.1L462,190.8z M92.4,397c-12-13.9-22.3-29.4-30.4-46.1l-29.8,11.9c9.9,20.7,22.6,39.8,37.6,56.9 L92.4,397z M272,40.6c18.8,1.4,36.9,5.2,54.1,11.1l12.6-29.5C317.7,14.7,295.3,10,272,8.5V40.6z M190.8,50 c15.7-5,32.2-8.2,49.2-9.4V8.5c-21.2,1.4-41.7,5.4-61.1,11.7L190.8,50z M442.3,92.3L419.6,115c12,13.9,22.3,29.4,30.5,46.1 l29.8-11.9C470,128.5,457.3,109.4,442.3,92.3z M397,92.4l22.7-22.7c-15.6-13.7-32.8-25.5-51.5-34.9l-12.6,29.5 C370.4,72.1,384.4,81.5,397,92.4z"})});var o=E(E({},a),{},{attributeName:"opacity"}),s={tag:"circle",attributes:E(E({},i),{},{cx:"256",cy:"364",r:"28"}),children:[]};return n||s.children.push({tag:"animate",attributes:E(E({},a),{},{attributeName:"r",values:"28;14;28;28;14;28;"})},{tag:"animate",attributes:E(E({},o),{},{values:"1;0;1;1;0;1;"})}),r.push(s),r.push({tag:"path",attributes:E(E({},i),{},{opacity:"1",d:"M263.7,312h-16c-6.6,0-12-5.4-12-12c0-71,77.4-63.9,77.4-107.8c0-20-17.8-40.2-57.4-40.2c-29.1,0-44.3,9.6-59.2,28.7 c-3.9,5-11.1,6-16.2,2.4l-13.1-9.2c-5.6-3.9-6.9-11.8-2.6-17.2c21.2-27.2,46.4-44.7,91.2-44.7c52.3,0,97.4,29.8,97.4,80.2 c0,67.6-77.4,63.5-77.4,107.8C275.7,306.6,270.3,312,263.7,312z"}),children:n?[]:[{tag:"animate",attributes:E(E({},o),{},{values:"1;0;0;0;0;1;"})}]}),n||r.push({tag:"path",attributes:E(E({},i),{},{opacity:"0",d:"M232.5,134.5l7,168c0.3,6.4,5.6,11.5,12,11.5h9c6.4,0,11.7-5.1,12-11.5l7-168c0.3-6.8-5.2-12.5-12-12.5h-23 C237.7,122,232.2,127.7,232.5,134.5z"}),children:[{tag:"animate",attributes:E(E({},o),{},{values:"0;0;1;1;0;0;"})}]}),{tag:"g",attributes:{class:"missing"},children:r}}}},hu={hooks:function(){return{parseNodeAttributes:function(n,r){var i=r.getAttribute("data-fa-symbol"),a=i===null?!1:i===""?!0:i;return n.symbol=a,n}}}},pu=[hc,tu,eu,nu,ru,lu,fu,cu,du,mu,hu];Pc(pu,{mixoutsTo:gt});gt.noAuto;gt.config;var Du=gt.library;gt.dom;var zr=gt.parse;gt.findIconDefinition;gt.toHtml;var gu=gt.icon;gt.layer;gt.text;gt.counter;function Ia(t,e){var n=Object.keys(t);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(t);e&&(r=r.filter(function(i){return Object.getOwnPropertyDescriptor(t,i).enumerable})),n.push.apply(n,r)}return n}function Rt(t){for(var e=1;e<arguments.length;e++){var n=arguments[e]!=null?arguments[e]:{};e%2?Ia(Object(n),!0).forEach(function(r){ft(t,r,n[r])}):Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(n)):Ia(Object(n)).forEach(function(r){Object.defineProperty(t,r,Object.getOwnPropertyDescriptor(n,r))})}return t}function vu(t,e){if(typeof t!="object"||!t)return t;var n=t[Symbol.toPrimitive];if(n!==void 0){var r=n.call(t,e||"default");if(typeof r!="object")return r;throw new TypeError("@@toPrimitive must return a primitive value.")}return(e==="string"?String:Number)(t)}function bu(t){var e=vu(t,"string");return typeof e=="symbol"?e:e+""}function Dn(t){"@babel/helpers - typeof";return Dn=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(e){return typeof e}:function(e){return e&&typeof Symbol=="function"&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},Dn(t)}function ft(t,e,n){return e=bu(e),e in t?Object.defineProperty(t,e,{value:n,enumerable:!0,configurable:!0,writable:!0}):t[e]=n,t}function yu(t,e){if(t==null)return{};var n={};for(var r in t)if(Object.prototype.hasOwnProperty.call(t,r)){if(e.indexOf(r)>=0)continue;n[r]=t[r]}return n}function xu(t,e){if(t==null)return{};var n=yu(t,e),r,i;if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(t);for(i=0;i<a.length;i++)r=a[i],!(e.indexOf(r)>=0)&&Object.prototype.propertyIsEnumerable.call(t,r)&&(n[r]=t[r])}return n}var wu=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{},as={exports:{}};(function(t){(function(e){var n=function(A,k,C){if(!c(k)||m(k)||v(k)||_(k)||l(k))return k;var D,U=0,L=0;if(u(k))for(D=[],L=k.length;U<L;U++)D.push(n(A,k[U],C));else{D={};for(var Q in k)Object.prototype.hasOwnProperty.call(k,Q)&&(D[A(Q,C)]=n(A,k[Q],C))}return D},r=function(A,k){k=k||{};var C=k.separator||"_",D=k.split||/(?=[A-Z])/;return A.split(D).join(C)},i=function(A){return j(A)?A:(A=A.replace(/[\-_\s]+(.)?/g,function(k,C){return C?C.toUpperCase():""}),A.substr(0,1).toLowerCase()+A.substr(1))},a=function(A){var k=i(A);return k.substr(0,1).toUpperCase()+k.substr(1)},o=function(A,k){return r(A,k).toLowerCase()},s=Object.prototype.toString,l=function(A){return typeof A=="function"},c=function(A){return A===Object(A)},u=function(A){return s.call(A)=="[object Array]"},m=function(A){return s.call(A)=="[object Date]"},v=function(A){return s.call(A)=="[object RegExp]"},_=function(A){return s.call(A)=="[object Boolean]"},j=function(A){return A=A-0,A===A},N=function(A,k){var C=k&&"process"in k?k.process:k;return typeof C!="function"?A:function(D,U){return C(D,A,U)}},B={camelize:i,decamelize:o,pascalize:a,depascalize:o,camelizeKeys:function(A,k){return n(N(i,k),A)},decamelizeKeys:function(A,k){return n(N(o,k),A,k)},pascalizeKeys:function(A,k){return n(N(a,k),A)},depascalizeKeys:function(){return this.decamelizeKeys.apply(this,arguments)}};t.exports?t.exports=B:e.humps=B})(wu)})(as);var _u=as.exports,Au=["class","style"];function Ou(t){return t.split(";").map(function(e){return e.trim()}).filter(function(e){return e}).reduce(function(e,n){var r=n.indexOf(":"),i=_u.camelize(n.slice(0,r)),a=n.slice(r+1).trim();return e[i]=a,e},{})}function ku(t){return t.split(/\s+/).reduce(function(e,n){return e[n]=!0,e},{})}function os(t){var e=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},n=arguments.length>2&&arguments[2]!==void 0?arguments[2]:{};if(typeof t=="string")return t;var r=(t.children||[]).map(function(l){return os(l)}),i=Object.keys(t.attributes||{}).reduce(function(l,c){var u=t.attributes[c];switch(c){case"class":l.class=ku(u);break;case"style":l.style=Ou(u);break;default:l.attrs[c]=u}return l},{attrs:{},class:{},style:{}});n.class;var a=n.style,o=a===void 0?{}:a,s=xu(n,Au);return uf(t.tag,Rt(Rt(Rt({},e),{},{class:i.class,style:Rt(Rt({},i.style),o)},i.attrs),s),r)}var ss=!1;try{ss=!0}catch{}function Eu(){if(!ss&&console&&typeof console.error=="function"){var t;(t=console).error.apply(t,arguments)}}function pr(t,e){return Array.isArray(e)&&e.length>0||!Array.isArray(e)&&e?ft({},t,e):{}}function Su(t){var e,n=(e={"fa-spin":t.spin,"fa-pulse":t.pulse,"fa-fw":t.fixedWidth,"fa-border":t.border,"fa-li":t.listItem,"fa-inverse":t.inverse,"fa-flip":t.flip===!0,"fa-flip-horizontal":t.flip==="horizontal"||t.flip==="both","fa-flip-vertical":t.flip==="vertical"||t.flip==="both"},ft(ft(ft(ft(ft(ft(ft(ft(ft(ft(e,"fa-".concat(t.size),t.size!==null),"fa-rotate-".concat(t.rotation),t.rotation!==null),"fa-pull-".concat(t.pull),t.pull!==null),"fa-swap-opacity",t.swapOpacity),"fa-bounce",t.bounce),"fa-shake",t.shake),"fa-beat",t.beat),"fa-fade",t.fade),"fa-beat-fade",t.beatFade),"fa-flash",t.flash),ft(ft(e,"fa-spin-pulse",t.spinPulse),"fa-spin-reverse",t.spinReverse));return Object.keys(n).map(function(r){return n[r]?r:null}).filter(function(r){return r})}function Ta(t){if(t&&Dn(t)==="object"&&t.prefix&&t.iconName&&t.icon)return t;if(zr.icon)return zr.icon(t);if(t===null)return null;if(Dn(t)==="object"&&t.prefix&&t.iconName)return t;if(Array.isArray(t)&&t.length===2)return{prefix:t[0],iconName:t[1]};if(typeof t=="string")return{prefix:"fas",iconName:t}}var $u=gl({name:"FontAwesomeIcon",props:{border:{type:Boolean,default:!1},fixedWidth:{type:Boolean,default:!1},flip:{type:[Boolean,String],default:!1,validator:function(e){return[!0,!1,"horizontal","vertical","both"].indexOf(e)>-1}},icon:{type:[Object,Array,String],required:!0},mask:{type:[Object,Array,String],default:null},maskId:{type:String,default:null},listItem:{type:Boolean,default:!1},pull:{type:String,default:null,validator:function(e){return["right","left"].indexOf(e)>-1}},pulse:{type:Boolean,default:!1},rotation:{type:[String,Number],default:null,validator:function(e){return[90,180,270].indexOf(Number.parseInt(e,10))>-1}},swapOpacity:{type:Boolean,default:!1},size:{type:String,default:null,validator:function(e){return["2xs","xs","sm","lg","xl","2xl","1x","2x","3x","4x","5x","6x","7x","8x","9x","10x"].indexOf(e)>-1}},spin:{type:Boolean,default:!1},transform:{type:[String,Object],default:null},symbol:{type:[Boolean,String],default:!1},title:{type:String,default:null},titleId:{type:String,default:null},inverse:{type:Boolean,default:!1},bounce:{type:Boolean,default:!1},shake:{type:Boolean,default:!1},beat:{type:Boolean,default:!1},fade:{type:Boolean,default:!1},beatFade:{type:Boolean,default:!1},flash:{type:Boolean,default:!1},spinPulse:{type:Boolean,default:!1},spinReverse:{type:Boolean,default:!1}},setup:function(e,n){var r=n.attrs,i=ie(function(){return Ta(e.icon)}),a=ie(function(){return pr("classes",Su(e))}),o=ie(function(){return pr("transform",typeof e.transform=="string"?zr.transform(e.transform):e.transform)}),s=ie(function(){return pr("mask",Ta(e.mask))}),l=ie(function(){return gu(i.value,Rt(Rt(Rt(Rt({},a.value),o.value),s.value),{},{symbol:e.symbol,title:e.title,titleId:e.titleId,maskId:e.maskId}))});An(l,function(u){if(!u)return Eu("Could not find one or more icon(s)",i.value,s.value)},{immediate:!0});var c=ie(function(){return l.value?os(l.value.abstract[0],{},r):null});return function(){return c.value}}});export{$u as F,Gl as a,Po as b,Mu as c,gl as d,pt as e,ju as f,Ru as g,Iu as h,Mt as i,Zr as j,ie as k,An as l,Nu as m,Vr as n,wl as o,Lu as p,Ql as q,Cu as r,ql as s,Pu as t,Gs as u,Fu as v,Tu as w,Du as x};
