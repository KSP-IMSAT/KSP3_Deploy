﻿
//async function getMeasureDataSummaryAll() {
//    console.log("getMeasureDataSummaryAll");
//    var respose = await fetch("/GetMeasureDataSummaryAll", {
//        method: "POST",
//        body: "{}",
//        headers: {
//            "Content-type": "application/json; charset=UTF-8"
//        }
//    });
//    var data = await respose.json();
//    console.log(data);
//}

//getMeasureDataSummaryAll();