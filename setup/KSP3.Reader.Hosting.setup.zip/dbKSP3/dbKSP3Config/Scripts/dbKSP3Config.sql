--{DatabaseName}
--{ForderData}
--{Year}

USE [master]
GO
/****** Object:  Database [{DatabaseName}]    Script Date: 18/08 12:13:05 ******/
CREATE DATABASE [{DatabaseName}]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'{DatabaseName}', FILENAME = N'{ForderData}\{DatabaseName}.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'{DatabaseName}_log', FILENAME = N'{ForderData}\{DatabaseName}_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
GO
ALTER DATABASE [{DatabaseName}] MODIFY FILEGROUP [PRIMARY] AUTOGROW_ALL_FILES
GO
ALTER DATABASE [{DatabaseName}] SET COMPATIBILITY_LEVEL = 140
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [{DatabaseName}].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [{DatabaseName}] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [{DatabaseName}] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [{DatabaseName}] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [{DatabaseName}] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [{DatabaseName}] SET ARITHABORT OFF 
GO
ALTER DATABASE [{DatabaseName}] SET AUTO_CLOSE ON 
GO
ALTER DATABASE [{DatabaseName}] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [{DatabaseName}] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [{DatabaseName}] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [{DatabaseName}] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [{DatabaseName}] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [{DatabaseName}] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [{DatabaseName}] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [{DatabaseName}] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [{DatabaseName}] SET  ENABLE_BROKER 
GO
ALTER DATABASE [{DatabaseName}] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [{DatabaseName}] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [{DatabaseName}] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [{DatabaseName}] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [{DatabaseName}] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [{DatabaseName}] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [{DatabaseName}] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [{DatabaseName}] SET RECOVERY SIMPLE 
GO
ALTER DATABASE [{DatabaseName}] SET  MULTI_USER 
GO
ALTER DATABASE [{DatabaseName}] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [{DatabaseName}] SET DB_CHAINING OFF 
GO
ALTER DATABASE [{DatabaseName}] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [{DatabaseName}] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [{DatabaseName}] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [{DatabaseName}] SET QUERY_STORE = OFF
GO
USE [{DatabaseName}]
GO
/****** Object:  User [dev]    Script Date: 18/08 12:13:05 ******/
CREATE USER [dev] WITHOUT LOGIN WITH DEFAULT_SCHEMA=[dbo]
GO
ALTER ROLE [db_owner] ADD MEMBER [dev]
GO
/****** Object:  Table [dbo].[DetectorConfig]    Script Date: 18/08 12:13:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DetectorConfig](
	[ID] [nvarchar](50) NOT NULL,
	[Group] [nvarchar](50) NULL,
	[State] [tinyint] NULL,
	[Range] [nvarchar](500) NULL,
	[CreateTime] [datetime] NULL,
	[UpdateTime] [datetime] NULL,
	[MinChart] [decimal](18, 5) NULL,
	[MaxChart] [decimal](18, 5) NULL,
	[MinValue] [int] NULL,
	[MaxValue] [int] NULL,
	[MinHightChart] [decimal](18, 5) NULL,
	[MaxHightChart] [decimal](18, 5) NULL,
	[ChartDrawType] [tinyint] NULL,
 CONSTRAINT [PK_DetectorConfig] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DetectorFormulaConfig]    Script Date: 18/08 12:13:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DetectorFormulaConfig](
	[ID] [uniqueidentifier] NOT NULL,
	[IDDetector] [nvarchar](50) NULL,
	[FormulaOfValue] [nvarchar](500) NULL,
	[FromValue] [int] NULL,
	[ToValue] [int] NULL,
	[FormulaType] [tinyint] NULL,
	[Comment] [nvarchar](500) NULL,
	[CreateTime] [datetime] NULL,
	[UpdateTime] [datetime] NULL,
	[State] [tinyint] NULL,
	[ChartType] [tinyint] NULL,
 CONSTRAINT [PK_DetectorFormulaConfig] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DeviceConfig]    Script Date: 18/08 12:13:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DeviceConfig](
	[ID] [uniqueidentifier] NOT NULL,
	[CreateTime] [datetime] NULL,
	[UpdateTime] [datetime] NULL,
	[State] [tinyint] NULL,
	[CopyID] [int] NULL,
	[CopyName] [nvarchar](100) NULL,
	[CopyCentral] [nvarchar](100) NULL,
	[CopyLine] [nvarchar](100) NULL,
	[CopyPosition] [nvarchar](100) NULL,
	[CopySensorKod] [nvarchar](100) NULL,
	[CopyStatus] [nvarchar](100) NULL,
	[Name] [nvarchar](50) NULL,
	[Central] [nvarchar](50) NULL,
	[Line] [nvarchar](50) NULL,
	[Position] [nvarchar](50) NULL,
	[SensorKod] [nvarchar](50) NULL,
	[Status] [nvarchar](50) NULL,
	[Detector] [nvarchar](50) NULL,
	[AG] [decimal](18, 5) NULL,
	[AO] [decimal](18, 5) NULL,
	[APS] [decimal](18, 5) NULL,
	[SwitchingOffType] [tinyint] NULL,
	[SwitchingOffControl] [tinyint] NULL,
	[DescriptionOfAlarmReceiver] [nvarchar](max) NULL,
	[SwitchedOfElectricEqipment] [nvarchar](max) NULL,
	[PA_AGChannels] [nvarchar](50) NULL,
	[PA_AOChannels] [nvarchar](50) NULL,
	[OutputsAlarms] [nvarchar](max) NULL,
	[StatusConfig] [nvarchar](50) NULL,
	[Area] [nvarchar](50) NULL,
	[DetectorDescription1] [nvarchar](50) NULL,
	[DetectorDescription2] [nvarchar](50) NULL,
	[DetectorDescription3] [nvarchar](50) NULL,
	[DetectorDescription4] [nvarchar](50) NULL,
	[TimeReader] [int] NULL,
	[IsOff] [bit] NULL,
	[TimeUnlockBlockingRequestCalib] [datetime] NULL,
 CONSTRAINT [PK__DeviceCo__3214EC27F8BDB6A8] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DeviceConfigTrack]    Script Date: 18/08 12:13:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DeviceConfigTrack](
	[ID] [uniqueidentifier] NOT NULL,
	[IDDevice] [uniqueidentifier] NOT NULL,
	[ChangeTime] [datetime] NOT NULL,
	[ChangeBy] [nvarchar](100) NULL,
	[CreateTime] [datetime] NULL,
	[UpdateTime] [datetime] NULL,
	[State] [tinyint] NULL,
	[CopyID] [int] NULL,
	[CopyName] [nvarchar](100) NULL,
	[CopyCentral] [nvarchar](100) NULL,
	[CopyLine] [nvarchar](100) NULL,
	[CopyPosition] [nvarchar](100) NULL,
	[CopySensorKod] [nvarchar](100) NULL,
	[CopyStatus] [nvarchar](100) NULL,
	[Name] [nvarchar](50) NULL,
	[Central] [nvarchar](50) NULL,
	[Line] [nvarchar](50) NULL,
	[Position] [nvarchar](50) NULL,
	[SensorKod] [nvarchar](50) NULL,
	[Status] [nvarchar](50) NULL,
	[Detector] [nvarchar](50) NULL,
	[AG] [decimal](18, 5) NULL,
	[AO] [decimal](18, 5) NULL,
	[APS] [decimal](18, 5) NULL,
	[SwitchingOffType] [tinyint] NULL,
	[SwitchingOffControl] [tinyint] NULL,
	[DescriptionOfAlarmReceiver] [nvarchar](max) NULL,
	[SwitchedOfElectricEqipment] [nvarchar](max) NULL,
	[PA_AGChannels] [nvarchar](50) NULL,
	[PA_AOChannels] [nvarchar](50) NULL,
	[OutputsAlarms] [nvarchar](max) NULL,
	[StatusConfig] [nvarchar](50) NULL,
	[Area] [nvarchar](50) NULL,
	[DetectorDescription1] [nvarchar](50) NULL,
	[DetectorDescription2] [nvarchar](50) NULL,
	[DetectorDescription3] [nvarchar](50) NULL,
	[DetectorDescription4] [nvarchar](50) NULL,
	[TimeReader] [int] NULL,
	[IsOff] [bit] NULL,
	[TimeUnlockBlockingRequestCalib] [datetime] NULL,
 CONSTRAINT [PK__DeviceCo__3214EC2785E0A99C] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SettingApp]    Script Date: 18/08 12:13:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SettingApp](
	[Key] [nvarchar](50) NOT NULL,
	[Value] [nvarchar](50) NULL,
	[Metadata] [nvarchar](max) NULL,
	[UpdateTime] [datetime] NULL,
 CONSTRAINT [PK_SettingApp] PRIMARY KEY CLUSTERED 
(
	[Key] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SyncTableMaster]    Script Date: 18/08 12:13:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SyncTableMaster](
	[ID] [nvarchar](50) NOT NULL,
	[TableName] [nvarchar](50) NULL,
	[ClientID] [nvarchar](50) NULL,
	[LastPointSync] [datetime] NULL,
	[Message] [nvarchar](500) NULL,
	[UpdateTime] [datetime] NULL,
	[IsSuccess] [bit] NULL,
 CONSTRAINT [PK_SyncTableMaster] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-20240416-125022]    Script Date: 18/08 12:13:05 ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20240416-125022] ON [dbo].[DetectorFormulaConfig]
(
	[IDDetector] ASC
)
INCLUDE([ID],[FormulaOfValue],[FromValue],[ToValue],[FormulaType],[Comment],[CreateTime],[UpdateTime],[State],[ChartType]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-20240416-124929]    Script Date: 18/08 12:13:05 ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20240416-124929] ON [dbo].[DeviceConfig]
(
	[CopyID] ASC,
	[Central] ASC,
	[Position] ASC
)
INCLUDE([ID],[CreateTime],[UpdateTime],[TimeUnlockBlockingRequestCalib],[DetectorDescription1],[DetectorDescription2],[DetectorDescription3],[DetectorDescription4],[TimeReader],[IsOff],[SwitchedOfElectricEqipment],[PA_AGChannels],[PA_AOChannels],[OutputsAlarms],[StatusConfig],[Area],[AG],[AO],[APS],[SwitchingOffType],[SwitchingOffControl],[DescriptionOfAlarmReceiver],[CopyStatus],[Name],[Line],[SensorKod],[Status],[Detector],[State],[CopyName],[CopyCentral],[CopyLine],[CopyPosition],[CopySensorKod]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [idx_DeviceConfigTrack_IDDevice_ChangeTime]    Script Date: 18/08 12:13:05 ******/
CREATE NONCLUSTERED INDEX [idx_DeviceConfigTrack_IDDevice_ChangeTime] ON [dbo].[DeviceConfigTrack]
(
	[IDDevice] ASC,
	[ChangeTime] ASC
)
INCLUDE([ChangeBy],[CreateTime],[UpdateTime],[State],[Name],[Central],[Line],[Position],[SensorKod],[Detector],[AG],[AO],[APS],[SwitchingOffType],[SwitchingOffControl],[DescriptionOfAlarmReceiver],[SwitchedOfElectricEqipment],[PA_AGChannels],[PA_AOChannels],[OutputsAlarms],[StatusConfig],[Area],[DetectorDescription1],[DetectorDescription2],[DetectorDescription3],[DetectorDescription4],[TimeReader],[IsOff]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE [dbo].[DeviceConfig] ADD  CONSTRAINT [DF__DeviceCon__CopyN__37A5467C]  DEFAULT (N'abc') FOR [CopyName]
GO
ALTER TABLE [dbo].[DeviceConfig] ADD  CONSTRAINT [DF__DeviceCon__CopyC__38996AB5]  DEFAULT (N'1') FOR [CopyCentral]
GO
ALTER TABLE [dbo].[DeviceConfig] ADD  CONSTRAINT [DF__DeviceCon__CopyL__398D8EEE]  DEFAULT (N'1') FOR [CopyLine]
GO
ALTER TABLE [dbo].[DeviceConfig] ADD  CONSTRAINT [DF__DeviceCon__CopyP__3A81B327]  DEFAULT (N'1') FOR [CopyPosition]
GO
ALTER TABLE [dbo].[DeviceConfig] ADD  CONSTRAINT [DF__DeviceCon__CopyS__3B75D760]  DEFAULT (N'Off') FOR [CopyStatus]
GO
ALTER TABLE [dbo].[DetectorFormulaConfig]  WITH CHECK ADD  CONSTRAINT [FK_DetectorFormulaConfig_DetectorConfig] FOREIGN KEY([IDDetector])
REFERENCES [dbo].[DetectorConfig] ([ID])
GO
ALTER TABLE [dbo].[DetectorFormulaConfig] CHECK CONSTRAINT [FK_DetectorFormulaConfig_DetectorConfig]
GO
USE [master]
GO
ALTER DATABASE [{DatabaseName}] SET  READ_WRITE 
GO
